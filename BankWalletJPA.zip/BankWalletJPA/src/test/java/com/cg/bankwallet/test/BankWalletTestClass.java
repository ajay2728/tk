package com.cg.bankwallet.test;

import static org.junit.jupiter.api.Assertions.*;


import java.util.List;
import java.util.Map;
import java.util.prefs.BackingStoreException;

import javax.swing.text.DefaultEditorKit.CutAction;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.bankwallet.bean.Account;
import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.dao.BankWalletDAO;
import com.cg.bankwallet.dao.IBankWalletDAO;
import com.cg.bankwallet.exception.BankWalletException;


class BankWalletTestClass 
{
	
	  public static IBankWalletDAO iBankWalletDAO;
	  public static Customer customer;
	  
	  @BeforeAll static void setUpBeforeClass() throws Exception 
	  {
	  iBankWalletDAO=new BankWalletDAO();
	  customer=new Customer();
	  }
	  
	  @AfterAll static void tearDownAfterClass() throws Exception
	  {
	  iBankWalletDAO=null;
	  customer=null; 
	  }
	  
	  @BeforeEach void setUp() throws Exception
	  {
		  iBankWalletDAO=new BankWalletDAO();
		  customer=new Customer(); 
		  }
	  
	  @AfterEach void tearDown() throws Exception
	  {
		  iBankWalletDAO=null;
		  customer=null;
	  
	  }
	  
	  @Test void testCreateAccount() throws BankWalletException 
	  {
	  
	  }
	  
	  @Test void testShowBalance()throws BankWalletException
	  {
	  }	  
	 
	  
	  @Test void testDeposit()throws BankWalletException
	  {
	  }
	
	  @Test void testWithdraw()throws BankWalletException
	  {
	  }
	 
	  @Test void testFundTransfer()throws BankWalletException 
	  {
	  }
	  
	  @Test void testPrintTransaction() throws BankWalletException
	  {

	  }
	  
	
	  
	 
	 
}
