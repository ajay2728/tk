package com.cg.bankwallet.dao;

import java.text.DateFormat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.bankwallet.bean.Account;
import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.exception.BankWalletException;


public class BankWalletDAO implements IBankWalletDAO {
List<Transaction> details=new ArrayList<Transaction>();
Date date;
EntityManagerFactory entityManagerFactory ;
EntityManager entityManager;
EntityTransaction entityTransaction ;
public BankWalletDAO()
{
	super();
	entityManagerFactory = Persistence.createEntityManagerFactory("jpa");
	 entityManager = entityManagerFactory.createEntityManager();
	 entityTransaction = entityManager.getTransaction();
	// TODO Auto-generated constructor stub
}

public Customer createAccount(Customer customer)throws BankWalletException {
	
	entityTransaction.begin();
	customer.setAccount(new Account(0));
		 entityManager.persist(customer);
		 entityTransaction.commit();
		if(entityManager.find(Customer.class, customer.getCustomerId())!=null)
		return customer;
		else
			return null;
	
	}

	public double showBalance(long customerId)throws BankWalletException {
		try
		{
		Customer customer=entityManager.find(Customer.class, customerId);
		return customer.getAccount().getBalance();
		}
		catch(NullPointerException e)
		{
			throw new BankWalletException("No such customer id exists");
		}
		finally
		{
			
		}
	}

	public boolean deposit(long customerId, double amount)throws BankWalletException {
		try
		{
			entityTransaction.begin();
		Customer customer=entityManager.find(Customer.class, customerId);
		
double  previousAmount=customer.getAccount().getBalance();
customer.getAccount().setBalance(previousAmount+amount);
System.out.println(customer.getAccount().getBalance());
date=Calendar.getInstance().getTime();
DateFormat dateFormat=new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
String currentTime=dateFormat.format(date);
details.add(new Transaction( "DEPOSIT", currentTime,Long.toString(customer.getAccount().getAccountNo()), amount,customer,customerId));
customer.setTransactions(details);
entityManager.merge(customer);
entityTransaction.commit();
	return false;
		}
		catch(NullPointerException e)
		{
			entityTransaction.commit();
			throw new BankWalletException("No such customer id exists");
		}
	}

	public boolean withdraw(long customerId, double amount)throws BankWalletException {
		try
		{
		
			entityTransaction.begin();
			Customer customer=entityManager.find(Customer.class, customerId);
		 if(customer.getAccount().getBalance()<amount)
			throw new BankWalletException("amount to be withdrawn is greater than available balance");
		else
		{
		double availableBalance=customer.getAccount().getBalance();
		customer.getAccount().setBalance(availableBalance-amount);
		date=Calendar.getInstance().getTime();
		DateFormat dateFormat=new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
		String currentTime=dateFormat.format(date);
		details.add(new Transaction( "WITHDRAW", currentTime,Long.toString(customer.getAccount().getAccountNo()),amount,customer,customerId));
		customer.setTransactions(details);
		entityManager.merge(customer);
		entityTransaction.commit();
		return false;
		}
		}
		catch(NullPointerException e)
		{
			entityTransaction.commit();
			throw new BankWalletException("No such customer id exists");
		}
	}

	public boolean fundTransfer(long customerId, double amount,long toCustomerId)throws BankWalletException {
		try
		{
			entityTransaction.begin();
			Customer customer=entityManager.find(Customer.class, customerId);
			Customer toCustomer=entityManager.find(Customer.class, toCustomerId);
			if(customer.getAccount().getBalance()<amount)
			throw new BankWalletException("amount to be transfered is greater than available balance");
		
double availableBal=customer.getAccount().getBalance();
customer.getAccount().setBalance(availableBal-amount);
		double toAvailableBal=toCustomer.getAccount().getBalance();
		toCustomer.getAccount().setBalance(toAvailableBal+amount);
		date=Calendar.getInstance().getTime();
		DateFormat dateFormat=new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
		String currentTime=dateFormat.format(date);
		details.add(new Transaction( "TRANSFER", currentTime,Long.toString(toCustomer.getAccount().getAccountNo()),amount,customer,customerId));
		customer.setTransactions(details);
		entityManager.merge(customer);
		entityManager.merge(toCustomer);
		entityTransaction.commit();
		return false;
		}
		
		catch(NullPointerException e)
		{
			throw new BankWalletException("No such customer id exists");
		}
	}

	public List<Transaction> printTransaction(long customerId)throws BankWalletException {
		try
		{
			System.out.println(customerId);
			TypedQuery<Transaction> query=entityManager.createQuery("select c from Transaction c where customerId=:id",Transaction.class);
			query.setParameter("id", customerId);
			List<Transaction> list=query.getResultList();
		if(list==null)
			throw new BankWalletException("no transactions till now");
		else
		return list;

		}
		catch(NullPointerException e)
		{
			throw new BankWalletException("No such customer id exists");
			
		}
	}
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		entityManager.close();
		entityManagerFactory.close();
	}

}
