package com.cg.bankwallet.exception;

public class BankWalletException extends Exception{

	/**
	 * 
	 */
	String message;
	private static final long serialVersionUID = 1L;
	public BankWalletException() {
		// TODO Auto-generated constructor stub
	}
	public BankWalletException(String message) {
		System.out.println(message);
		this.message=message;
		
	}
	@Override
	public String getMessage() {
		return message;
	}
	
	
}
