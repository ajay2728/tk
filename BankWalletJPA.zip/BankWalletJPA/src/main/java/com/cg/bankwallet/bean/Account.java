package com.cg.bankwallet.bean;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="account_details")
public class Account implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "bankseq")
	@SequenceGenerator(name = "bankseq",sequenceName ="bankwalletaccountseq",initialValue = 200,allocationSize = 1 )
	int accountNo; 
	double balance;
	@OneToOne(cascade = CascadeType.ALL,mappedBy = "account")
	private Customer customer;
	
	
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account( double balance) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	

}
