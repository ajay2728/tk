package com.cg.bankwallet.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.exception.BankWalletException;
import com.cg.bankwallet.service.BankWalletService;
import com.cg.bankwallet.service.IBankWalletService;
/**
 * 
 * @author basaini
 *
 */
public class Client {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		
		IBankWalletService iBankWalletService=new BankWalletService();
System.out.println("Welcome to the bank wallet");

do
	{
	
	System.out.println("1) Create Account\n2) Deposit\n3) Withdraw\n4) Transfer Money\n5 Show Balance\n6) Print Transactions\n 7) Exit");
	
	Scanner scanner=new Scanner(System.in);
	
	int choice=scanner.nextInt();
	switch(choice)
	{
	case 1:
	{try
	{
		System.out.print("Enter the name: ");
		String name=br.readLine();
		System.out.print("Enter the mobileNo: ");
		String mobileNo=br.readLine();
		if(!mobileNo.matches("[0-9]+"))
			throw new BankWalletException("Mobile no should have only digits");
		if(mobileNo.length()!=10)
			throw new BankWalletException("Mobile no should be of 10 digits only");
		
		System.out.print("Enter the address: ");
		String address=br.readLine();
		System.out.print("Enter the email: ");
		String email=br.readLine();
		if(!email.contains("@"))
			throw new BankWalletException("Email id is not valid");
		System.out.print("Enter your date of birth: ");
		String dob=br.readLine();
		Customer custdetails=iBankWalletService.createAccount(new Customer(name,dob,mobileNo,email,address,null,null));
	System.out.print("Note Down\n Your Customer ID: "+custdetails.getCustomerId()+"\n  Your Account No: "+custdetails.getAccount().getAccountNo());
	}
	
	catch (BankWalletException e) {
		
	}
	catch(IOException e)
	{
		System.out.println("parsing problem");
	}
		break;
	
	}
	
	case 2:
{
	try
	{
		
	System.out.print("Enter your customer id: ");
	long customerId=Long.parseLong(br.readLine());
	System.out.print("Enter the amount to be deposited: ");
	double amount=Double.parseDouble(br.readLine());
	
	iBankWalletService.deposit(customerId, amount);
	
	}
	catch(BankWalletException e)
	{
		
	}
	catch(InputMismatchException e) {
		System.out.print("enter digits only");
	}
	catch(IOException e)
	{
		System.out.println("parsing problem");
	}
	}
break;
	case 3:
{try
{
	System.out.print("Enter your Customer ID: ");
	long customerId=Long.parseLong(br.readLine());
	System.out.print("Enter the amount to be withdrawn:");
	double amount=Double.parseDouble(br.readLine());
	iBankWalletService.withdraw(customerId, amount);
}catch(BankWalletException e)
{
	
}catch(InputMismatchException e) {
	System.out.print("enter digits only");
}
catch(IOException e)
{
	System.out.println("parsing problem");
}
	}
break;
	case 4:
{
	try
	{
	System.out.print("Enter your Customer ID: ");
	long customerId=Long.parseLong(br.readLine());
	System.out.print("Enter the amount to transfer:");
	double amount=Double.parseDouble(br.readLine());
	System.out.print("Enter the Customer ID for transfer: ");
	long toCustomerId=Long.parseLong(br.readLine());
	iBankWalletService.fundTransfer(customerId, amount, toCustomerId);
	}
	catch(BankWalletException e)
	{
		
	}catch(InputMismatchException e) {
		System.out.print("enter digits only");
	}
	catch(IOException e)
	{
		System.out.println("parsing problem");
	}
	}
break;
	case 5:
{try {
	System.out.print("Enter your Customer ID: ");
	long customerId=Long.parseLong(br.readLine());
	System.out.print(iBankWalletService.showBalance(customerId));
} catch (BankWalletException e) {
}	catch(InputMismatchException e) {
	System.out.print("enter digits only");
}
catch(IOException e)
{
	System.out.println("parsing problem");
}
	}
break;
	case 6:
{
	try {
		System.out.print("Enter your Customer ID: ");
		long customerId=Long.parseLong(br.readLine());
		System.out.println("client"+customerId);
		List<Transaction> list=iBankWalletService.printTransaction(customerId);
		System.out.println(list.size());
			for(int i=0;i<list.size();i++)
			{
				System.out.print("Transaction type: "+list.get(i).getTransactionType());
				System.out.print("Amount: "+list.get(i).getAmount());
				System.out.print("Time: "+list.get(i).getTransactionDate());
				if(list.get(i).getTransactionType().equalsIgnoreCase("transfer"))
				System.out.print("Transfer to CustomerID: "+list.get(i).getToAccountNo());
				System.out.println();
					
			}
	} catch (BankWalletException e) {
		// TODO Auto-generated catch block
		
	}catch(InputMismatchException e) {
		System.out.print("enter digits only");
	}
	catch(IOException e)
	{
		System.out.println("parsing problem");
	}
		
		
	}
	break;
	case 7:
{
	System.exit(0);
	break;	
	}
	
		default:
		{
			System.out.print("Enter the correct input");
			break;
		}
			
	}
	}while(true);
	
	
	
	
	
	
	}
	

}
