package com.cg.bankwallet.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="customer_details")
public class Customer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "bankseq")
	@SequenceGenerator(name = "bankseq",sequenceName ="bankwalletcustomerseq",initialValue = 200,allocationSize = 1 )
	long customerId;
	String customerName;
	String dateOfBirth;
	String phone;
	String email;
	String address;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="account_no")
	Account account;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "customer")
	List<Transaction> transactions;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer( String customerName, String dateOfBirth, String phone, String email, String address,
			Account account, List<Transaction> transactions) {
		super();
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.account = account;
		this.transactions = transactions;
	}
	public long  getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long  customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	
	
}
