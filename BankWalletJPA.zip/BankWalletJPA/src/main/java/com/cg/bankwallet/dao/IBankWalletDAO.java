package com.cg.bankwallet.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.exception.BankWalletException;

public interface IBankWalletDAO {
	Map<Integer, Transaction> transactionMap = new HashMap<Integer, Transaction>();
	public  Customer createAccount(Customer customer)throws BankWalletException; 
		public double showBalance(long customerId)throws BankWalletException;
		public boolean deposit(long customerId, double amount)throws BankWalletException;
		public boolean withdraw(long customerId, double amount)throws BankWalletException;
		public boolean fundTransfer(long customerId, double amount,long toCustomerId)throws BankWalletException;
		List<Transaction> printTransaction(long customerId)throws BankWalletException;

}
