package com.cg.bankwallet.bean;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
 
@Entity
@Table(name="transaction_details")
public class Transaction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "bankseq")
	@SequenceGenerator(name = "bankseq",sequenceName ="bankwallettransactionseq",initialValue = 5000,allocationSize = 1 )
	int transactionId;
   	String transactionType;
	String transactionDate;
	String toAccountNo;
	double amount;
	@ManyToOne(cascade = CascadeType.ALL)
	
	private Customer customer;
	private long customerId;
	
	public int getTransactionId() {
		return transactionId;
	}
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
	public Transaction(String transactionType, String transactionDate, String toAccountNo, double amount,
			Customer customer, long customerId) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
		this.customer = customer;
		this.customerId = customerId;
	}

	public Transaction(int transactionId, String transactionType, String transactionDate, String toAccountNo,
			double amount, Customer customer) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
		this.customer = customer;
	}

	public Transaction(String transactionType, String transactionDate, String toAccountNo, double amount,
			Customer customer) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
		this.customer = customer;
	}

	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getToAccountNo() {
		return toAccountNo;
	}
	public void setToAccountNo(String toAccountNo) {
		this.toAccountNo = toAccountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	
	
	

}
