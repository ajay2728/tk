package com.cg.bankWallet.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "customers_details3")
public class Customer implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "customerseq3")
	@SequenceGenerator(name = "customerseq3",sequenceName ="csequence3",initialValue = 200,allocationSize = 1 )
	private int customerId;
	@Column(length = 12)
	private String mobileNumber;
	@Column(length = 15)
	private String customerName;
	@Column (length = 10)
	private String userName;
	@Column(length = 15)
	private String passWord;
	@Column(length = 25)
	private String email;
	@OneToOne (cascade = CascadeType.ALL)
	@JoinColumn(name = "accountNumber")
	private Account account;
	@OneToMany(cascade = CascadeType.ALL , mappedBy = "customer")
	List<Transaction> transactions=new ArrayList<Transaction>();
	@OneToOne (cascade = CascadeType.ALL)
	@JoinColumn(name = "doorNumber")
	private Address address;
	public Customer() {
		super();
		
	}
	
	public Customer(String customerName, String mobileNumber, String userName, String passWord, String email,
			Address address , Account account) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.userName = userName;
		this.passWord = passWord;
		this.email = email;
		this.address = address;
		this.account = account;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", mobileNumber=" + mobileNumber + ", passWord=" + passWord
				+ ", email=" + email + ", account=" + account + ",address=" + address
				+ "]";
	}
	
	
	

}
