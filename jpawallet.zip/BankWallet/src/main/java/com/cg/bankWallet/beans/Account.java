package com.cg.bankWallet.beans;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "accounts_details3")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "accountseq3")
	@SequenceGenerator(name = "accountseq3" , sequenceName = "asequence3" ,initialValue = 500 , allocationSize =1)
	@Column(length = 15)
    private int accountNumber;
	@Column(length = 15)
    private double balance = 0;
	@OneToOne(cascade = CascadeType.ALL , mappedBy = "account")
	Customer customer;
    
	public Account() {
		super();
		
	}

	public Account(double balance) {
		super();
		this.balance = balance;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", balance=" + balance + ", customer=" + customer + "]";
	}
	
	
	
    
}
