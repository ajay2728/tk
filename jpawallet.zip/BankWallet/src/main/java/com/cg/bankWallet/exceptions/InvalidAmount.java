package com.cg.bankWallet.exceptions;

public class InvalidAmount extends Exception {
	
	
	
	public InvalidAmount(String message) {
		System.out.println(message);
	}

	@Override
	public String getMessage() {
		return "Invalid Amount";
	}
	
	

}
