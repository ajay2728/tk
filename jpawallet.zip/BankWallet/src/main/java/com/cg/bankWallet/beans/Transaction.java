package com.cg.bankWallet.beans;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name = "transaction_details3")
public class Transaction implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "transactionseq3")
	@SequenceGenerator(name = "transactionseq3" , sequenceName = "tsequence3" ,initialValue = 500 , allocationSize =1)
	private int transactionNumber;
	private String transactionId;
	String transactionType;
	String beneficiaryName;
	int accountNumber;
	double amount;
	String currentDate;
	double avlBalance;
    @ManyToOne(cascade = CascadeType.ALL)
	Customer customer;
    private int customerId;
    
	public Transaction() {
		super();
	}

	
	


	public Transaction(String transactionId, String transactionType, String beneficiaryName, int accountNumber,
			double amount, String currentDate, double avlBalance , int customerId) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.beneficiaryName = beneficiaryName;
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.currentDate = currentDate;
		this.avlBalance = avlBalance;
		this.customerId = customerId;
	}





	public Transaction(String type, String transactionId, double amount,
			String date, double avlBalance , int customerId) {
		super();
		this.transactionType = type;
		this.transactionId = transactionId;
		this.amount = amount;
		this.currentDate = date;
		this.avlBalance = avlBalance;
		this.customerId = customerId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}





	@Override
	public String toString() {
		return "Transaction [transactionNumber=" + transactionNumber + ", transactionId=" + transactionId
				+ ", transactionType=" + transactionType + ", amount=" + amount + ", currentDate=" + currentDate
				+ ", avlBalance=" + avlBalance + "]";
	}

	
}
