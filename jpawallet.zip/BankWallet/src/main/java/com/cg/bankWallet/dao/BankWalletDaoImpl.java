package com.cg.bankWallet.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.bankWallet.beans.Account;
import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.beans.Transaction;

public class BankWalletDaoImpl {
	Date date;
	String transactionId = "TCI0001254";
	EntityManagerFactory factory;
	EntityManager manager;
	EntityTransaction transact;
	
	

	public BankWalletDaoImpl() {
		super();
		factory = Persistence.createEntityManagerFactory("BankWallet_Plp");
		manager = factory.createEntityManager();
		transact = manager.getTransaction();
	}

	public boolean createAccount(Customer customer) {
		boolean flag = false;
		transact.begin();
		manager.persist(customer);
		transact.commit();
		if (manager.find(Customer.class, customer.getCustomerId()) != null) {
			flag = true;
		}
		return flag;
	}

	public double getBalance(int customerId) {
		return manager.find(Customer.class, customerId).getAccount().getBalance();
	}

	public Customer getCustomer(int customerId) {
		return manager.find(Customer.class, customerId);
	}

	public boolean withDraw(int customerId, double amount) {
		boolean flag = true;
		Customer customer = manager.find(Customer.class, customerId);
		double accountBalance = customer.getAccount().getBalance();
		if (accountBalance < amount) {
			flag = false;
		} else {
			accountBalance -= amount;
			customer.getAccount().setBalance(accountBalance);
			int transactSuffix = (int) (Math.random()) * 1000;
			transactionId += transactSuffix;
			date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
			String currentTime = dateFormat.format(date);
			double availableBalance = getBalance(customerId);
			Transaction transaction = new Transaction("withdraw", transactionId, amount, currentTime, availableBalance ,customerId);
			transact.begin();
			manager.merge(customer);
			manager.persist(transaction);
			transact.commit();
		}
		return flag;

	}

	public boolean deposit(int customerId, double amount) {
		boolean flag = true;
		Customer customer = manager.find(Customer.class, customerId);
		double accountBalance = customer.getAccount().getBalance();
		double previousBalance = accountBalance;
		accountBalance += amount;
		customer.getAccount().setBalance(accountBalance);
		transact.begin();
		manager.merge(customer);
		transact.commit();

		if (getBalance(customerId) > previousBalance) {
			int transactSuffix = (int) (Math.random()) * 1000;
			transactionId += transactSuffix;
			date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
			String currentTime = dateFormat.format(date);
			double availableBalance = getBalance(customerId);
			Transaction transaction = new Transaction("Deposit", transactionId, amount, currentTime, availableBalance , customerId);
			transact.begin();
			manager.persist(transaction);
			transact.commit();
		} else {
			System.out.println("Something Went Wrong..!");
		}
		return flag;
	}

	public boolean fundTransfer(int customerId, int  beneficiaryId, double amount) {
		boolean flag = false;
		Customer customer = manager.find(Customer.class, customerId);
		Customer beneficiary = manager.find(Customer.class, beneficiaryId);
		double customerBalance = customer.getAccount().getBalance();
		double previousCustomerBalance = customerBalance;
		double beneficiaryBalance = beneficiary.getAccount().getBalance();
		double previousBeneficiaryBalance = beneficiaryBalance;
		if (customerBalance > amount) {
			customerBalance -= amount;
			beneficiaryBalance += amount;
			customer.getAccount().setBalance(customerBalance);
			beneficiary.getAccount().setBalance(beneficiaryBalance);
			transact.begin();
			manager.merge(customer);
			manager.merge(beneficiary);
			transact.commit();
			if (getBalance(customerId) < previousCustomerBalance
					&& getBalance(beneficiaryId) > previousBeneficiaryBalance) {
				flag = true;
				int transactSuffix = (int) (Math.random()) * 1000;
				transactionId += transactSuffix;
				date = Calendar.getInstance().getTime();
				DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
				String currentTime = dateFormat.format(date);

				Transaction customerTransaction = new Transaction("Debited", transactionId,
						beneficiary.getCustomerName(), beneficiary.getAccount().getAccountNumber(), amount, currentTime,
						customerBalance , customerId);
				Transaction beneficiaryTransaction = new Transaction("Credited", transactionId,
						customer.getCustomerName(), customer.getAccount().getAccountNumber(), amount, currentTime,
						beneficiaryBalance , beneficiaryId);
				transact.begin();
				manager.persist(customerTransaction);
				manager.persist(beneficiaryTransaction);
				transact.commit();

			}
		} else {
			System.out.println("Transaction Failed due to Insufficient funds");
		}
		return flag;
	}

	
	public List<Transaction> viewTransaction(int customerId) {
		TypedQuery<Transaction> query = manager.createQuery("select c from Transaction c where customerId=:id",
				Transaction.class);
		query.setParameter("id", customerId);
		List<Transaction> transactions = new ArrayList<Transaction>();
			transactions = query.getResultList();
			System.out.println("ajay");
		return transactions;
	}
	
	
	@Override
	protected void finalize() throws Throwable {
	
		manager.close();
		factory.close();
	}

}
