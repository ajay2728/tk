package com.cg.bankWallet.service;

import java.util.List;
import java.util.Scanner;

import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.beans.Transaction;
import com.cg.bankWallet.dao.BankWalletDaoImpl;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BankWalletServiceImpl  {

	BankWalletDaoImpl dataAccessObject = new BankWalletDaoImpl();


	public Customer getCustomer(int customerId) {

		return dataAccessObject.getCustomer(customerId);
	}

	public boolean createAccount(Customer customer) {
		return dataAccessObject.createAccount(customer);
	}


	public boolean withDraw(int customerId  , double amount) {
		return dataAccessObject.withDraw(customerId, amount);
	}

	public boolean fundTransfer(int customerId, int beneficiaryId , double amount) {
		
		return dataAccessObject.fundTransfer(customerId, beneficiaryId, amount);

	}

	public boolean deposit(int customerId, double amount) {
		
		return dataAccessObject.deposit(customerId, amount);
	}
	
	public double showBalance(int customerId) {
		return dataAccessObject.getBalance(customerId);
	}

	public void printTransactions(int customerId) {

		List<Transaction> transactions = dataAccessObject.viewTransaction(customerId);
		System.out.println("ajay1");
		System.out.println(transactions.size());

		for (Transaction transaction : transactions) {

			System.out.println(transaction);
		}

	}

}
