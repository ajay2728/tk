package com.cg.bankWallet.ui;

import java.util.Scanner;

import javax.print.attribute.standard.Severity;

import com.cg.bankWallet.beans.Account;
import com.cg.bankWallet.beans.Address;
import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.service.BankWalletServiceImpl;

public class Client {
	public static void main(String[] args) {
		boolean terminator = true; 
		boolean terminator2;
		Scanner scanner = new Scanner(System.in);
		BankWalletServiceImpl serviceObject = new BankWalletServiceImpl();
		

		do {
			System.out.println("\n1.New User\n2.login\n3.exit");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				System.out.println("Enter Your Name");
				String customerName = scanner.next();
				System.out.println("Enter Mobile Number");
				String mobileNumber = scanner.next();
				System.out.println("Select your username");
				String userName = scanner.next();
				System.out.println("Select your password");
				String password = scanner.next();
				System.out.println("Enter your email");
				String email = scanner.next();
				System.out.println("Enter your address \n1.City\n2.State\n3.Postal Code");
				String city = scanner.next();
				String state = scanner.next();
				String postalCode = scanner.next();
				
				Address address = new Address(city, state, postalCode);
                Account account = new Account();
				Customer customer = new Customer(customerName, mobileNumber, userName, password, email,
						address , account);
			    customer.setAccount(new Account(0));
				if(serviceObject.createAccount(customer)) {

				System.out.println("Congractulations! Account created Successfully...");
				}else {
					System.out.println("Something went Wrong Try Again");
				}
				break;

			}
			case 2: {
				System.out.println("Enter your customeId");
				int customerId = scanner.nextInt();
				Customer customer = serviceObject.getCustomer(customerId);
				if (!(customer == null)) {
					System.out.println("Enter Your Password");
					String password = scanner.next();
					String original = customer.getPassWord();
					if (original.equals(password)) {
                       System.out.println(customer.getCustomerId());
                       System.out.println(customer.getCustomerName());
                       System.out.println(customer.getAddress().getCity());
						do {
						    terminator2 = true;
							System.out.println("What operation do u want to perform");
							System.out.println(
									"\n1.Show Balance.\n2.withdraw\n3.Deposit\n"
									+ "4.Fund Transfer\n5.Print your Transactions\n6.logout");
							int option = scanner.nextInt();
							switch (option) {
							case 1: {
		
							double avalBalance = serviceObject.showBalance(customer.getCustomerId());
							System.out.println("Your Account balance is: " + avalBalance);
								break;
							}
							case 2: {
								System.out.println("Enter amount to withdraw");
								double amount = scanner.nextDouble();
								if (serviceObject.withDraw(customer.getCustomerId() , amount)) {
									System.out.println("Transaction is successful");
									System.out
											.println("Available Balance is\t: " + (customer.getAccount().getBalance()));
									break;
								} else {
									System.out.println("Transaction is failed due to inefficient balance");
									System.out.println("Available Balance is\t: " + (customer.getAccount().getBalance()));
									break;
								}
							}

							case 3: {
								
								System.out.println("Enter Amount to deposit");
								double amount = scanner.nextDouble();
							
								if(serviceObject.deposit(customer.getCustomerId(), amount)) {
								double avlBalance = customer.getAccount().getBalance();
								System.out.println("Amount is deposited successfully");
								System.out.println( "\nDeposit Amount\t: "
										+ amount + "\nTotal Balance\t: " + avlBalance);
								break;
								}else {
									System.out.println("Invalid amount");
									break;
								}
							}
							case 4: {
								System.out.println("Enter Registered user customerId");
								int  custID = scanner.nextInt();
								System.out.println("Enter amount transfer");
								double amount = scanner.nextDouble();
								System.out.println("Enter your password Again");
								String custPassword = scanner.next();
								if(custPassword.equals(customer.getPassWord())){
								boolean flag = serviceObject.fundTransfer(customer.getCustomerId(), custID ,amount);
								if (flag) {
									System.out.println("Fund transfer is successful with TransactionId :");
									break;
								} else {
									System.out.println("Something went wrong");
									break;
								}
								}else {
								System.out.println("Wrong password");
								break;
							}
							}
							case 5: {
								int primaryKey = customer.getCustomerId();
								serviceObject.printTransactions(primaryKey);
								break;
							}
							case 6 :{
								terminator2 = false;
								break;
							}
							default: {
								System.out.println("select 1-5 operations only");
							}

							}
						} while (terminator2);
						break;

					} else {
						System.out.println("Invalid password"); 
						break;
					}

				} else {
					System.out.println("Your are not registered");
					break;
				}
			}
			case 3: {
				System.exit(0);
			}
			default: {
				System.out.println("Enter between 1-2 Only");
			}

			}
			
		} while (terminator);

	}

}
