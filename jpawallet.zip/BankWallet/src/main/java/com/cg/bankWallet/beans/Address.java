package com.cg.bankWallet.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name = "address_details3")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "addressseq3")
	@SequenceGenerator(name = "addressseq3" , sequenceName = "adsequence3" ,initialValue = 1202, allocationSize =1)
	int doorNumber;
    private String city;
    private String state;
    private String postalCode;
    @OneToOne(cascade = CascadeType.ALL , mappedBy = "address")
    Customer customer;
	public Address() {
		super();
	}
	
	public Address(String city, String state, String postalCode) {
		super();
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", postalCode=" + postalCode + "]";
	}
    
     
}
