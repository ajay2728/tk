package com.cg.bankWallet.dao;

import java.util.List;
import java.util.Map;

import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.beans.Transaction;

public interface IBankWalletDao {
     boolean createAccount(Customer customer);
     Customer getCustomer(String phoneNumber);
     List<Transaction> viewTransaction(String mobileNumber);
     
}
