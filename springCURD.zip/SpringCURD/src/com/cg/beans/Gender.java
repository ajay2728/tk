package com.cg.beans;

import org.springframework.stereotype.Component;

@Component
public class Gender {
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	 
}
