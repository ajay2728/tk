package com.cg.dao;

import java.util.List;

import com.cg.beans.Customer;

public interface CustomerRepositry {
	
	public void save(Customer customer);
	public void update(Customer customer);
	public boolean delete(int custId);
	public Customer getById(int custId);
	List<Customer> getCustomers();
	public Customer validate(String username , String password);
    
	
	

}
