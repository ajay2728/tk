package com.cg.bankWallet.service;

import com.cg.bankWallet.beans.Customer;

public interface IBankWalletService {
	
		boolean createAccount(Customer customer);
		double showBalance(Customer customer);
		double withDraw(Customer customer , double amount);
	    void fundTransfer(Customer customer , String mobileNumber);
	    void printTransactions();

	

}
