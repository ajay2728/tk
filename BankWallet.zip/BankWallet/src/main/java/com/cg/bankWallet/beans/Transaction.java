package com.cg.bankWallet.beans;

public class Transaction {
    public String type;
	String transactionId;
	String beneficiaryName;
	String accountNumber;
	double amount;
	String date;
	
	public Transaction() {
		super();
	}
	public Transaction(String transactionId, String beneficiaryName, String accountNumber, double amount, String date) {
		super();
		this.transactionId = transactionId;
		this.beneficiaryName = beneficiaryName;
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.date = date;
	}
	@Override
	public String toString() {
		return "\nTransactionId\t:\t" + transactionId + "\nBeneficiaryName\t:\t" + beneficiaryName
				+ "\nAccountNumber\t:\t" + accountNumber + "\nAmount=" + amount + "\nDate\t:\t" + date;
	}
	
	
	
	
}
