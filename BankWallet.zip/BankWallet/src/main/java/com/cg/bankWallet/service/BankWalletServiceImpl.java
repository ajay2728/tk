package com.cg.bankWallet.service;

import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.dao.BankWalletDaoImpl;

public class BankWalletServiceImpl implements IBankWalletService {
    
	BankWalletDaoImpl dataAccessObject = new BankWalletDaoImpl();
	
	public boolean createAccount(Customer customer) {
		dataAccessObject.createAccount(customer);
		return true;
	}

	public double showBalance(Customer customer) {
		
		return customer.getAccount().getBalance();
	}

	public double withDraw(Customer customer , double amount) {
		double accountBalance = customer.getAccount().getBalance();
		if(customer.getAccount().getBalance() < amount) {
			System.out.println("Transaction Failed in sufficient funds");
		}
		else {
		     accountBalance -= amount;
		}
		return accountBalance ;
	}

	public void fundTransfer(Customer customer ,String mobileNumber) {
		Customer beneficiary = dataAccessObject.functionalities(mobileNumber);
		double totalBalance = (beneficiary.getAccount().getBalance())+(customer.getAccount().getBalance());
		beneficiary.getAccount().setBalance(totalBalance);
		dataAccessObject.insertTransactions(customer , beneficiary);
		
	}

	public void printTransactions() {
		
		
	}
	
	

}
