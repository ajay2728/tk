package com.cg.bankWallet.beans;

public class Customer {
	private String customerName;
	private String mobileNumber;
	private String passWord;
	private String email;
	private Account account;
	private Transaction transation;
	private Address address;
	public Customer() {
		super();
		
	}
	public Customer(String customerName, String mobileNumber, String passWord, String email, Account account,
			Transaction transation, Address address) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.passWord = passWord;
		this.email = email;
		this.account = account;
		this.transation = transation;
		this.address = address;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Transaction getTransation() {
		return transation;
	}
	public void setTransation(Transaction transation) {
		this.transation = transation;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", mobileNumber=" + mobileNumber + ", passWord=" + passWord
				+ ", email=" + email + ", account=" + account + ", transation=" + transation + ", address=" + address
				+ "]";
	}
	
	
	

}
