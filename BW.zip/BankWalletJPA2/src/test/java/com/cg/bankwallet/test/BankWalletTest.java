package com.cg.bankwallet.test;

import static org.junit.jupiter.api.Assertions.*;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.dao.IWalletDao;
import com.cg.bankwallet.dao.WalletDaoImpl;

class BankWalletTest {
	static IWalletDao dao,dao1;
	Customer customer;
	Customer customer1;
	Customer customer2;
	Customer customer3;
	static EntityManagerFactory factory;
	static EntityManager manager;
	
	boolean result = false;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao = new WalletDaoImpl();
		factory=Persistence.createEntityManagerFactory("jpa");
		manager=factory.createEntityManager();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao =null;
		manager=null;
		factory=null;
	}

	@BeforeEach
	void setUp() throws Exception {
		customer = new Customer();
		customer1 = new Customer();
		customer2 = new Customer();
		customer3= new Customer();
	}

	@AfterEach
	void tearDown() throws Exception {
		customer=null;
		customer1=null;
		customer2=null;
		customer3=null;
	}

	@Test
	void testCreateAccount() {
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		customer.setPassword("Yuva@123");
		customer1.setCustomerName("abinandha");
		customer1.setDateOfBirth("01-04-1998");
		customer1.setPhone("9876435210");
		customer1.setEmail("Abinandha@gmail.com");
		customer1.setAddress("vellore");
		customer1.setPassword("Abi@123");
		customer2= dao.createAccount(customer);
		customer3= dao.createAccount(customer1);
		if(customer2!=null && customer3!=null) {
			result =true;
		}
		assertTrue(result==true);
	}

	@Test
	void testShowBalance() {
		result = false;
		/*
		 * customer.setCustomerName("yuvanesh"); customer.setDateOfBirth("02-03-1997");
		 * customer.setPhone("9334209088"); customer.setEmail("yuvanesh2296@gmail.com");
		 * customer.setAddress("vellore"); customer.setPassword("Yuva@123");
		 * dao.createAccount(customer);
		 */
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c where c.customerName=:name", Customer.class);
		query.setParameter("name", "yuvanesh");
		customer2= query.getSingleResult();
		double balance =dao.showBalance(customer2.getCustomerId());
		if(balance==0) {
			result =true;
		}
		assertTrue(result == true);
	}

	@Test
	void testDeposit() {
		result = false;
		/*
		 * customer.setCustomerName("yuvanesh"); customer.setDateOfBirth("02-03-1997");
		 * customer.setPhone("9334209088"); customer.setEmail("yuvanesh2296@gmail.com");
		 * customer.setAddress("vellore"); customer.setPassword("Yuva@123");
		 * dao.createAccount(customer);
		 */
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c where c.customerName=:name", Customer.class);
		query.setParameter("name", "yuvanesh");
		customer2= query.getSingleResult();
		result=dao.deposit(customer2.getCustomerId(), 15000);
		assertTrue(result==true);
	}

	@Test
	void testWithdraw() {
		result = false;
		/*
		 * customer.setCustomerName("yuvanesh"); customer.setDateOfBirth("02-03-1997");
		 * customer.setPhone("9334209088"); customer.setEmail("yuvanesh2296@gmail.com");
		 * customer.setAddress("vellore"); dao.createAccount(customer);
		 * customer.setPassword("Yuva@123");
		 */
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c where c.customerName=:name", Customer.class);
		query.setParameter("name", "yuvanesh");
		customer2= query.getSingleResult();
		result=dao.withdraw(customer2.getCustomerId(), 5000);
		assertTrue(result==true);
	}

	@Test
	void testFundTransfer() {
		result = false;
		/*
		 * customer.setCustomerName("yuvanesh"); customer.setDateOfBirth("02-03-1997");
		 * customer.setPhone("9334209088"); customer.setEmail("yuvanesh2296@gmail.com");
		 * customer.setAddress("vellore"); customer.setPassword("Yuva@123");
		 * customer1.setCustomerName("abinandha");
		 * customer1.setDateOfBirth("01-04-1998"); customer1.setPhone("9876435210");
		 * customer1.setEmail("Abinandha@gmail.com"); customer1.setAddress("vellore");
		 * customer1.setPassword("Abi@123"); Map<String, Integer>
		 * idAccountDetailsMap=dao.createAccount(customer); Map<String, Integer>
		 * idAccountDetailsMap2=dao.createAccount(customer1);
		 * dao.deposit(idAccountDetailsMap.get("customerId"), 10000);
		 */
		//System.out.println(createAccountMap2.get("customerId"));
		//dao.deposit(createAccountMap2.get("customerId"), 10000);
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c where c.customerName=:name", Customer.class);
		query.setParameter("name", "yuvanesh");
		customer2= query.getSingleResult();
		TypedQuery<Customer> query1 = manager.createQuery("select c from Customer c where c.customerName=:name", Customer.class);
		query1.setParameter("name", "abinandha");
		customer3= query.getSingleResult();
		result=dao.fundTransfer(customer2.getCustomerId(),customer3.getCustomerId(), 5000);
		assertTrue(result==true);

	}

	@Test
	void testPrintTransaction() {
		/*
		 * result = false; customer.setCustomerName("yuvanesh");
		 * customer.setDateOfBirth("02-03-1997"); customer.setPhone("9334209088");
		 * customer.setEmail("yuvanesh2296@gmail.com"); customer.setAddress("vellore");
		 * customer1.setCustomerName("abinandha");
		 * customer1.setDateOfBirth("01-04-1998"); customer1.setPhone("9876435210");
		 * customer1.setEmail("Abinandha@gmail.com"); customer1.setAddress("vellore");
		 * customer1.setPassword("Abi@123"); Map<String, Integer>
		 * idAccountDetailsMap=dao.createAccount(customer);
		 * dao.createAccount(customer1);
		 */
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c where c.customerName=:name", Customer.class);
		query.setParameter("name", "yuvanesh");
		customer2= query.getSingleResult();
		List<Transaction> transactions = dao.printTransaction(customer2.getCustomerId());
		
		assertEquals(3,transactions.size());
	}

	@Test
	void testValidatePhone() {
		result =false;
		String phone = "9867503214";
		result = dao.validatePhone(phone);
		assertTrue(result==true);
	}

	@Test
	void testValidateEmail() {
		result =false;
		String email = "yuvanesh2296@gmail.com";
		result = dao.validateEmail(email);
		assertTrue(result==true);
	}

	

	@Test
	void testValidateCustomerId() {
		result =false;
		/*
		 * customer.setCustomerName("yuvanesh"); customer.setDateOfBirth("02-03-1997");
		 * customer.setPhone("9334209088"); customer.setEmail("yuvanesh2296@gmail.com");
		 * customer.setAddress("vellore"); dao.createAccount(customer);
		 */
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c where c.customerName=:name", Customer.class);
		query.setParameter("name", "yuvanesh");
		customer2= query.getSingleResult();
		result = dao.validateCustomerId(customer2.getCustomerId());
		assertTrue(result==true);
	}

	
}
