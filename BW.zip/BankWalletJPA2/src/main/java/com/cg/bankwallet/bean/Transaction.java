package com.cg.bankwallet.bean;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
@Entity
public class Transaction implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mySeq")
	@SequenceGenerator(name = "mySeq", sequenceName = "transaction1",initialValue = 1001,allocationSize = 1)
	@Column(length = 5, unique = true)
	int transactionId;
	@Column(length = 15)
	String transactionType;
	@Column(length = 30)
	String transactionDate;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="customer_id")
	Customer customer;
	@Column(length = 5)
	int customerId;
	@Column(length = 5)
	int accountNo;
	@Column(length = 15, precision = 10, scale = 2)
	String amount;

	public Transaction() {
		super();
	}

	

	
	public Transaction(String transactionType, String transactionDate, int customerId, int toAccountNo, String amount) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.customerId = customerId;
		this.accountNo = toAccountNo;
		this.amount = amount;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getToAccountNo() {
		return accountNo;
	}

	public void setToAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "\nTransaction Id=" + transactionId + "\nTransactionType=" + transactionType + "\nTransactionDate="
				+ transactionDate + "\nCustomer Id=" + customerId + "\nAccount No=" + accountNo + "\nAmount=" + amount;
	}

}
