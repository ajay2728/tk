package com.cg.bankwallet.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
@Entity
public class Account implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy =GenerationType.SEQUENCE,generator = "mySeq")
	@SequenceGenerator(name = "mySeq", sequenceName = "account1", initialValue = 6250,allocationSize = 1)
	@Column(length = 5, unique = true)
	int accountNo;
	@Column(length = 15, precision = 10, scale = 2)
	double balance;

	public Account() {
		super();
	}

	
	public Account(double balance) {
		super();
		this.balance = balance;
	}


	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "accountNo=" + accountNo + ", balance=" + balance;
	}

}
