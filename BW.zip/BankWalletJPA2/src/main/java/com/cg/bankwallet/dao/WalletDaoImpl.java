package com.cg.bankwallet.dao;

import java.text.DateFormat;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.bankwallet.bean.Account;
import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.exception.ZeroBalanceException;

public class WalletDaoImpl implements IWalletDao {
	List<Transaction> transactions = new ArrayList<Transaction>();
	Transaction transaction, transaction2, transaction3;
	EntityManagerFactory factory;
	EntityManager manager;
	EntityTransaction entityTransaction;
	boolean result = false;
	int id = 0;

	public WalletDaoImpl() {
		factory = Persistence.createEntityManagerFactory("jpa");
		manager = factory.createEntityManager();
		entityTransaction = manager.getTransaction();
	}

	@Override
	public Customer createAccount(Customer customer) {
		Account account = new Account(0);
		customer.setAccount(account);
		entityTransaction.begin();
		manager.persist(customer);
		entityTransaction.commit();
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c where c.customerName=:name",
				Customer.class);
		query.setParameter("name", customer.getCustomerName());
		Customer customer2 = query.getSingleResult();
		
		return customer2;
	}

	@Override
	public double showBalance(int customerId) {
		Customer customer = manager.find(Customer.class, customerId);
		double balance = customer.getAccount().getBalance();
		return balance;
	}

	@Override
	public boolean deposit(int customerId, double amount) {
		result = false;
		double balance = showBalance(customerId);
		double preBalance = balance;
		balance = balance + amount;
		Customer customer = manager.find(Customer.class, customerId);
		customer.getAccount().setBalance(balance);
		entityTransaction.begin();
		manager.merge(customer);
		entityTransaction.commit();
		if (showBalance(customerId) > preBalance) {
			result = true;
			int toAccount = customer.getAccount().getAccountNo();
			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			String strDate = dateFormat.format(date);
			transaction = new Transaction("Deposit", strDate, customerId, toAccount, Double.toString(amount));
			entityTransaction.begin();
			manager.persist(transaction);
			entityTransaction.commit();
		}
		return result;
	}

	@Override
	public boolean withdraw(int customerId, double amount) {
		result = false;
		double balance = 0;
		try {
			balance = showBalance(customerId);
			if (balance == 0) {
				throw new ZeroBalanceException("account balance is zero...");
			}
		} catch (ZeroBalanceException e) {
			System.out.println(e.getMessage());
		}
		double preBalance = balance;
		balance = balance - amount;
		Customer customer = manager.find(Customer.class, customerId);
		customer.getAccount().setBalance(balance);
		entityTransaction.begin();
		manager.merge(customer);
		entityTransaction.commit();
		if (showBalance(customerId) < preBalance) {
			result = true;
			int toAccount = customer.getAccount().getAccountNo();
			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			String strDate = dateFormat.format(date);
			transaction2 = new Transaction("Withdraw", strDate, customerId, toAccount, Double.toString(amount));
			entityTransaction.begin();
			manager.persist(transaction2);
			entityTransaction.commit();

		}
		return result;
	}

	@Override
	public boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount) {
		result = false;
		double withdrawBalance = 0;
		try {
			withdrawBalance = showBalance(fromCustomerId);
			if (withdrawBalance == 0) {
				throw new ZeroBalanceException();
			}
		} catch (ZeroBalanceException e) {
			System.out.println(e.getMessage());
		}
		if (withdrawBalance != 0) {
			double preBalance = withdrawBalance;
			withdrawBalance = withdrawBalance - amount;
			Customer customer = manager.find(Customer.class, fromCustomerId);
			customer.getAccount().setBalance(withdrawBalance);
			entityTransaction.begin();
			manager.merge(customer);
			entityTransaction.commit();
			double transferBalance = showBalance(toCustomerId);
			double transferPreBalance = transferBalance;
			transferBalance = transferBalance + amount;
			Customer customer2 = manager.find(Customer.class, toCustomerId);
			customer2.getAccount().setBalance(transferBalance);
			entityTransaction.begin();
			manager.merge(customer2);
			entityTransaction.commit();
			if (showBalance(fromCustomerId) < preBalance && showBalance(toCustomerId) > transferPreBalance) {
				result = true;
				int toAccount = customer2.getAccount().getAccountNo();
				Date date = Calendar.getInstance().getTime();
				DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
				String strDate = dateFormat.format(date);
				transaction3 = new Transaction("Fund Transfer", strDate, fromCustomerId, toAccount,
						Double.toString(amount));
				entityTransaction.begin();
				manager.persist(transaction3);
				entityTransaction.commit();
			}

		}
		return result;
	}

	@Override
	public List<Transaction> printTransaction(int customerId) {
		TypedQuery<Transaction> query = manager
				.createQuery("Select t from Transaction t where t.customerId=:customerId", Transaction.class);
		query.setParameter("customerId", customerId);
		transactions = query.getResultList();
		return transactions;
	}

	@Override
	public boolean validatePhone(String phone) {
		result = false;
		if (phone.matches("[0-9]+") && phone.length() == 10) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean validateEmail(String email) {
		result = false;
		String emailRegEx = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		Pattern pattern = Pattern.compile(emailRegEx);
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean validatePassword(String password) {
		result = false;
		String passwordRegEx = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		Pattern pattern = Pattern.compile(passwordRegEx);
		Matcher matcher = pattern.matcher(password);
		if (matcher.matches()) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean validateCustomerId(int customerId) {
		result = false;
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c", Customer.class);
		List<Customer> customers = query.getResultList();
		for (Customer customer : customers) {
			if (customerId == customer.getCustomerId()) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public boolean validateLoginPassword(String password) {
		result = false;
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c", Customer.class);
		List<Customer> customers = query.getResultList();
		for (Customer customer : customers) {
			if (password.equals(customer.getPassword())) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public List<Integer> getCustomerIds() {
		TypedQuery<Customer> query = manager.createQuery("select c from Customer c", Customer.class);
		List<Customer> customers = query.getResultList();
		List<Integer> customerIds = new ArrayList<Integer>();
		for (Customer customer : customers) {
			customerIds.add(customer.getCustomerId());
		}
		return customerIds;
	}

	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		manager.close();
		factory.close();
	}

}
