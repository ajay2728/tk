package com.cg.bankwallet.dao;

import java.util.List;


import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;

public interface IWalletDao {
	Customer createAccount(Customer customer);

	double showBalance(int customerId);

	boolean deposit(int customerId, double amount);

	boolean withdraw(int customerId, double amount);

	boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount);

	List<Transaction> printTransaction(int customerId);

	boolean validatePhone(String phone);

	boolean validateEmail(String email);
	
	boolean validatePassword(String password);
	
	boolean validateCustomerId(int customerId);
	
	boolean validateLoginPassword(String password);
	
	List<Integer> getCustomerIds();
}
