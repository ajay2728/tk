package com.cg.bankwallet.service;

import java.util.List;


import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;

public interface IWalletService {
	Customer createAccount(Customer customer);

	double showBalance(int customerId);

	boolean deposit(int customerId, double amount);

	boolean withdraw(int customerId, double amount);

	boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount);

	List<Transaction> printTransaction(int customerId);

	boolean validatePhone(String phone);

	boolean validateEmail(String email);

	boolean validateCustomerId(int customerId);
	
	boolean validatePassword(String password);
	
	boolean validateLoginPassword(String password);
	
	List<Integer> getCustomerIds();

}
