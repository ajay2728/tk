package com.cg.bankwallet.exception;

public class ZeroBalanceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ZeroBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ZeroBalanceException(String message) {
		super(message);
	}

	@Override
	public String getMessage() {
		return "account balance is zero...";
	}
	
	
}
