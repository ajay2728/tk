package com.cg.bankwallet.utitility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//import com.cg.bankwallet.bean.Account;
import com.cg.bankwallet.bean.Customer;
//import com.cg.bankwallet.bean.Transaction;

public class StaticDb {
	public static Map<Integer, Customer> customerMap = new HashMap<Integer, Customer>();

	static {
		/*
		 * Account account = new Account(17895, 50000); Account account2 = new
		 * Account(14326, 5000); Account account3 = new Account(12687, 70000);
		 * Transaction transaction = new Transaction(12, "Deposit", "14-06-2012", 126,
		 * 17895, "50000"); Transaction transaction2 = new Transaction(13, "withdraw",
		 * "18-04-2014", 142, 14326, "45000"); Transaction transaction3 = new
		 * Transaction(14, "fund transfer", "10-06-2010", 164, 17895, "20000");
		 * 
		 * Customer customer = new Customer("sanjay", "12-12-1987", "9876543210",
		 * "sanjay@gmail.com",
		 * "1/120, nehru street, ganesh nagar, mumbai, maharastra, 500041");
		 * customer.setCustomerId(126); customer.setAccount(account);
		 * customer.setTransaction(transaction); Customer customer2 = new
		 * Customer("sam", "11-10-1999", "9876543210", "sam@gmail.com",
		 * "1/32, vivekananda street, madikeri, Bangalore, karnataka, 560012");
		 * customer2.setCustomerId(142); customer2.setAccount(account2);
		 * customer2.setTransaction(transaction2); Customer customer3 = new
		 * Customer("velmurugan", "10-07-1998", "9647820165", "velumurgan@gmail.com",
		 * "14, shanthi colony, R.R nagar, telangana,650120");
		 * customer3.setCustomerId(164); customer3.setAccount(account3);
		 * customer3.setTransaction(transaction3); customerMap.put(126, customer);
		 * customerMap.put(142, customer2); customerMap.put(164, customer3);
		 */
	}

	public static Map<Integer, Customer> getCustomerDetails() {
		return customerMap;
	}

	public static List<Integer> getCustomerIds() {
		Collection<Customer> collect = customerMap.values();
		List<Integer> customerIdList = new ArrayList<Integer>();
		for (Customer customer : collect) {
			customerIdList.add(customer.getCustomerId());
		}
		return customerIdList;
	}
}
