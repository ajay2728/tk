package com.cg.bankwallet;

//import java.util.InputMismatchException;
//import java.util.List;
//import java.util.Collection;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import com.cg.bankwallet.bean.Transaction;
//import com.cg.bankwallet.exception.NegativeAmountException;

//import javax.persistence.TypedQuery;

//import com.cg.bankwallet.bean.Transaction;
//import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.service.IWalletService;
import com.cg.bankwallet.service.WalletServiceImpl;
//import com.cg.bankwallet.utitility.StaticDb;

public class RemovedMethods {
	IWalletService service = new WalletServiceImpl();
	Scanner scanner = new Scanner(System.in);
	boolean result = false;
	/*
	 * { do {
	 * 
	 * System.out.print("\nEnter the password: "); String password =
	 * scanner.next().trim(); result = service.validatePassword(password); if
	 * (result == false) { System.out.
	 * println("PassWord must have lowercase,uppercase,special characters and special symbols"
	 * ); } } while (result != true); }
	 */

	public boolean validateLoginPassword(String password) {
		/*
		 * result = false; Collection<Customer> collect =
		 * StaticDb.getCustomerDetails().values(); for (Customer customers : collect) {
		 * if (password.equals(customers.getPassword())) { result = true; } }
		 */
		return result;
	}

	public boolean validatePassword(String password) {
		result = false;
		String passwordRegEx = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		Pattern pattern = Pattern.compile(passwordRegEx);
		Matcher matcher = pattern.matcher(password);
		if (matcher.matches()) {
			result = true;
		}
		return result;
	}

	/*
	 * TypedQuery<Transaction> query = manager
	 * .createQuery("select t from Transaction t where t.transactionType=:transactionType"
	 * , Transaction.class); query.setParameter("transactionType",
	 * transaction2.getTransactionType()); transaction2 = query.getSingleResult();
	 * transactions.add(transaction2);
	 */

/*{ 
	case 1: {
	int customerId = 0;

	do {
		result=false;
		System.out.print("\nEnter the Customer ID:");
		try {
			customerId = scanner.nextInt();
			result = true;
		} catch (InputMismatchException e) {
			result = false;
			System.out.println("Enter only Digits...");
		}
	} while (result != true);

	result = false;
	result = service.validateCustomerId(customerId);

	if (result) {
		result = false;

		System.out.println("Enter the Password");
		String password = scanner.next().trim();

		result = service.validateLoginPassword(password);

		if (result) {
			int option1 = 0;
			result = false;
			do {
				System.out.println();
				System.out.println(
						"1.Show Balance\n2.Deposit\n3.Withdraw\n4.Fund Transfer\n5.Print Transaction\n6.Logout");

				do {
					System.out.print("Enter the option: ");
					try {
						option1 = scanner.nextInt();
						result = true;
					} catch (InputMismatchException e2) {
						System.out.println("Enter only digits");
					}
				} while (result != true);

				switch (option1) {
				case 1: {
					double balance = service.showBalance(customerId);
					System.out.println("\nBalance: " + balance);
				}
					break;

				case 2: {
					
					double amount = 0;

					do {
						result = false;
						System.out.print("\nEnter the amount to be deposited: ");
						try {
							amount = scanner.nextDouble();
							if (amount <= 0) {
								throw new NegativeAmountException();
							}
							result = true;
						} catch (NegativeAmountException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e4) {
							result = false;
							System.out.println("Enter only digits");
						}
					} while (result != true);

					result = false;
					result = service.deposit(customerId, amount);

					if (result) {
						System.out.println();
						System.out.println("Amount added successfully...........");
					} else {
						System.out.println("Amount is not added, try again!.......");
					}
				}
					break;

				case 3: {
					double amount = 0;

					do {
						result = false;
						System.out.print("\nEnter the amount to be withdrawn: ");
						try {
							amount = scanner.nextDouble();
							if (amount <= 0) {
								throw new NegativeAmountException();
							}
							result = true;
						} catch (NegativeAmountException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {
							result = false;
							System.out.println("Enter digits only");
						}
					} while (result != true);

					result = false;
					result = service.withdraw(customerId, amount);

					if (result) {
						System.out.println();
						System.out.println("Amount withdrawal successful......");
					} else {
						System.out.println("Amount cannot be withdrawn, try again!....");
					}
				}
					break;

				case 4: {
					int toCustomerId = 0;

					System.out.println("Customer ID's");
					for (int customerIds1 : service.getCustomerIds()) {
						System.out.println(customerIds1);
					}

					do {
						result = false;
						System.out
								.println("Enter the customer ID to which the amount has to be transferred");
						toCustomerId = scanner.nextInt();
						result = service.validateCustomerId(toCustomerId);
						if (result == false) {
							System.out.println("Customer Id not found");
						}
					} while (result != true);

					
					double amount = 0;

					do {
						result = false;
						System.out.println("Enter the amount to be transferred");
						try {
							amount = scanner.nextDouble();
							if (amount <= 0) {
								throw new NegativeAmountException();
							}
							result = true;
						} catch (NegativeAmountException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {
							result = true;
							System.out.println("Enter digits only");
						}
					} while (result != true);

					result = false;
					result = service.fundTransfer(customerId, toCustomerId, amount);

					if (result) {
						System.out.println();
						System.out.println("Fund Transfer Successful.......");
					} else {
						System.out.println("Fund Transfer not successfull, try again....");
					}
				}
					break;

				case 5: {
					List<Transaction> transactions = service.printTransaction(customerId);
					for (Transaction transaction : transactions) {
						if (transaction == null) {
							System.out.println("No transactions are made in this account..");
						} else {
							System.out.println(transaction);
						}
					}
				}

				case 6: {
					option1 = 6;
				}
					break;

				default: {
					System.out.println("Enter options only from 1 to 6");
				}
					break;
				}

			} while (option1 != 6);
		} else {
			System.out.println("Invalid Password");
		}

	} else {
		System.out.println("Customer Id does not exist");
	}

	System.out.println();
}
	break;
}*/

}
