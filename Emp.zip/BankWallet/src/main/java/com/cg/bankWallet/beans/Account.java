package com.cg.bankWallet.beans;

public class Account {
    private String accountNumber;
    private double balance = 0;
    
    
	public Account() {
		super();
		
	}
	
	public Account(String accountNumber) {
		super();
		this.accountNumber = accountNumber;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
    
    
}
