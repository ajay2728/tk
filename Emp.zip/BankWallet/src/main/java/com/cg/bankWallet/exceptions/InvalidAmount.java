package com.cg.bankWallet.exceptions;

public class InvalidAmount extends Exception {

	@Override
	public String getMessage() {
		return "Invalid Amount";
	}
	
	

}
