package com.cg.bankWallet.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Customer implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "myseq")
	@SequenceGenerator(name = "myseq" , sequenceName = "employee1" ,initialValue = 100 , allocationSize =1)
	@Column(length = 12)
	private String mobileNumber;
	@Column(length = 15)
	private String customerName;
	@Column (length = 10)
	private String userName;
	@Column(length = 15)
	private String passWord;
	@Column(length = 20)
	private String email;
	@Column(length = 15)
	private Account account;
	@Column(length = 15)
	@OneToMany(mappedBy = "customer")
	private Transaction transation;
	@Column(length = 15)
	private Address address;
	public Customer() {
		super();
		
	}
	
	public Customer(String customerName, String mobileNumber, String userName, String passWord, String email,
			Account account, Address address) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.userName = userName;
		this.passWord = passWord;
		this.email = email;
		this.account = account;
		this.transation = transation;
		this.address = address;
	}

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Transaction getTransation() {
		return transation;
	}
	public void setTransation(Transaction transation) {
		this.transation = transation;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", mobileNumber=" + mobileNumber + ", passWord=" + passWord
				+ ", email=" + email + ", account=" + account + ", transation=" + transation + ", address=" + address
				+ "]";
	}
	
	
	

}
