package com.cg.bankWallet.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.beans.Transaction;
import com.cg.bankWallet.repo.DataCenter;

public class BankWalletDaoImpl implements IBankWalletDao {
    EntityManagerFactory factory = Persistence.createEntityManagerFactory("BankWallet");
    EntityManager manager = factory.createEntityManager();
    EntityTransaction transaction = manager.getTransaction();
    
	public boolean createAccount(Customer customer) {
		boolean flag = false;
        transaction.begin();
        manager.persist(customer);
        transaction.commit();
		return flag;
	}

	public Customer functionalities(String phoneNumber) {
		return manager.find(Customer.class , phoneNumber);
	}
	
	public void insertTransactions(Customer customer ,Customer beneficiary ) {
            transaction.begin();
			manager.merge(customer);
			manager.merge(beneficiary);
			transaction.commit();
		
		
	}
	
	public boolean insertDeposits(Customer depositor) {
		transaction.begin();
		manager.merge(depositor);
		transaction.commit();
		
		return false;
	}

	public List<Transaction> viewTransaction(String mobileNumber) {
	 Query query = manager.createQuery("from Transaction where customerId = mobileNumber");
	 List<Transaction> transactions = query.getResultList();	
	 return transactions;
	}

}
