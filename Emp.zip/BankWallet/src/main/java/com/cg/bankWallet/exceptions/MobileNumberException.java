package com.cg.bankWallet.exceptions;

public class MobileNumberException {

}
