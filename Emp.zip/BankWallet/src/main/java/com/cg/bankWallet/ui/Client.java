package com.cg.bankWallet.ui;

import java.util.Scanner;

import javax.print.attribute.standard.Severity;

import com.cg.bankWallet.beans.Account;
import com.cg.bankWallet.beans.Address;
import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.service.BankWalletServiceImpl;

public class Client {
	public static void main(String[] args) {
		boolean terminator = true; 
		boolean terminator2;
		Scanner scanner = new Scanner(System.in);
		BankWalletServiceImpl serviceObject = new BankWalletServiceImpl();
		

		do {
			System.out.println("\n1.New User\n2.login\n3.exit");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				System.out.println("Enter Your Name");
				String customerName = scanner.next();
				System.out.println("Enter Mobile Number");
				String mobileNumber = scanner.next();
				System.out.println("Select your username");
				String userName = scanner.next();
				System.out.println("Select your password");
				String password = scanner.next();
				System.out.println("Enter your email");
				String email = scanner.next();
				System.out.println("Enter your address \n1.City\n2.State\n3.Postal Code");
				String city = scanner.next();
				String state = scanner.next();
				String postalCode = scanner.next();
				Address address = new Address(city, state, postalCode);

				String accountNumber = "348156478453";
                int random = (int)(Math.random() * 1000);
                accountNumber += random;
				Account account = new Account(accountNumber);

				Customer customer = new Customer(customerName, mobileNumber, userName, password, email, account,
						address);
				serviceObject.createAccount(customer);

				System.out.println("Congractulations! Account created Successfully...");
				break;

			}
			case 2: {
				System.out.println("Enter your mobile Number");
				String mobileNumber = scanner.next();
				Customer customer = serviceObject.retriveRecords(mobileNumber);
				if (!(customer == null)) {
					System.out.println("Enter Your Password");
					String password = scanner.next();
					String original = customer.getPassWord();
					if (original.equals(password)) {

						do {
						    terminator2 = true;
							System.out.println("What operation do u want to perform");
							System.out.println(
									"\n1.Show Balance.\n2.withdraw\n3.Deposit\n"
									+ "4.Fund Transfer\n5.Print your Transactions\n6.logout");
							int option = scanner.nextInt();
							switch (option) {
							case 1: {
								double avlBalance = serviceObject.showBalance(customer);
								System.out.println("Your Account Balance is\t:" + avlBalance);
								break;
							}
							case 2: {
								System.out.println("Enter amount to withdraw");
								double amount = scanner.nextDouble();
								if (serviceObject.withDraw(customer, amount)) {
									System.out.println("Transaction is successful");
									System.out
											.println("Available Balance is\t: " + (customer.getAccount().getBalance()));
									break;
								} else {
									System.out.println("Transaction is failed due to inefficient balance");
									System.out.println("Available Balance is\t: " + (customer.getAccount().getBalance()));
									break;
								}
							}

							case 3: {
								double previousBalance = customer.getAccount().getBalance();
								System.out.println("Enter Amount to deposit");
								double amount = scanner.nextDouble();
								if(!(amount < 0)) {
								double avlBalance = serviceObject.deposit(customer, amount);
								System.out.println("Amount is deposited successfully");
								System.out.println("Account balance\t: " + previousBalance + "\nDeposit Amount\t: "
										+ amount + "\nTotal Balance\t: " + avlBalance);
								break;
								}else {
									System.out.println("Invalid amount");
									break;
								}
							}
							case 4: {
								System.out.println("Enter Registered user mobile number");
								String phoneNumber = scanner.next();
								boolean flag = serviceObject.fundTransfer(customer, phoneNumber);
								if (flag) {
									System.out.println("Fund transfer is successful with TransactionId : "
											+ customer.getTransation().getTransactionId());
									break;
								} else {
									System.out.println("Something went wrong");
									break;
								}
							}
							case 5: {
								String primaryKey = customer.getMobileNumber();
								serviceObject.printTransactions(primaryKey);
								break;
							}
							case 6 :{
								terminator2 = false;
								break;
							}
							default: {
								System.out.println("select 1-5 operations only");
							}

							}
						} while (terminator2);
						break;

					} else {
						System.out.println("Invalid password"); 
						break;
					}

				} else {
					System.out.println("Your are not registered");
					break;
				}
			}
			case 3: {
				System.exit(0);
			}
			default: {
				System.out.println("Enter between 1-2 Only");
			}

			}
			
		} while (terminator);

	}

}
