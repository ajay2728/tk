package com.capg.buisness;

public class Book extends WrittenItem {

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(int uid, String title, int noOfCopies, String author) {
		super(uid, title, noOfCopies, author);
		// TODO Auto-generated constructor stub
	}

	public Book(int uid, String title, int noOfCopies) {
		super(uid, title, noOfCopies);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

}
