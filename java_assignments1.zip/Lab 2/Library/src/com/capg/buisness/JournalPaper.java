/**
 * 
 */
package com.capg.buisness;

/**
 * @author Yuvanesh
 *
 */
public class JournalPaper extends WrittenItem {
	private int yearPublished;

	public JournalPaper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JournalPaper(int uid, String title, int noOfCopies, String author) {
		super(uid, title, noOfCopies, author);
		// TODO Auto-generated constructor stub
	}

	public JournalPaper(int uid, String title, int noOfCopies) {
		super(uid, title, noOfCopies);
		// TODO Auto-generated constructor stub
	}

	public JournalPaper(int uid, String title, int noOfCopies, String author, int yearPublished) {
		this(uid, title, noOfCopies, author);
		this.yearPublished = yearPublished;
	}

	public int getYearPublished() {
		return yearPublished;
	}

	public void setYearPublished(int yearPublished) {
		this.yearPublished = yearPublished;
	}

	@Override
	public String toString() {
		return "JournalPaper [" + super.toString() + " yearPublished=" + yearPublished + "]";
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

}
