package com.capg.buisness;

public class Video extends MediaItem {
	private String director;
	private String genre;
	private int yearReleased;

	public Video() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Video(int uid, String title, int noOfCopies, int runtime) {
		super(uid, title, noOfCopies, runtime);
		// TODO Auto-generated constructor stub
	}

	public Video(int uid, String title, int noOfCopies) {
		super(uid, title, noOfCopies);
		// TODO Auto-generated constructor stub
	}

	public Video(int uid, String title, int noOfCopies, int runtime, String director, String genre, int yearReleased) {
		this(uid, title, noOfCopies, runtime);
		this.director = director;
		this.genre = genre;
		this.yearReleased = yearReleased;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getYearReleased() {
		return yearReleased;
	}

	public void setYearReleased(int yearReleased) {
		this.yearReleased = yearReleased;
	}

	@Override
	public String toString() {
		return "Video [" + super.toString() + " director=" + director + ", genre=" + genre + ", yearReleased="
				+ yearReleased + "]";
	}

}
