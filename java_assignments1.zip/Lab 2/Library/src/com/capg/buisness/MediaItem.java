package com.capg.buisness;

public abstract class MediaItem extends Item {
	private int runtime;

	public MediaItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MediaItem(int uid, String title, int noOfCopies) {
		super(uid, title, noOfCopies);
		// TODO Auto-generated constructor stub
	}

	public MediaItem(int uid, String title, int noOfCopies, int runtime) {
		this(uid, title, noOfCopies);
		this.runtime = runtime;
	}

	public int getRuntime() {
		return runtime;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	@Override
	public String toString() {
		return "MediaItem [" + super.toString() + " runtime=" + runtime + "]";
	}
}
