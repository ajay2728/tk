package com.capg.service;

import com.capg.buisness.Book;
import com.capg.buisness.CD;
import com.capg.buisness.Item;
import com.capg.buisness.JournalPaper;
import com.capg.buisness.Video;

public class Service {	
	public void processLibrary(Item i) {
		// TODO Auto-generated method stub
		if(i instanceof Book) {
			Book b = (Book) i;
			System.out.println(b);
		}
		if(i instanceof JournalPaper) {
			JournalPaper jp = (JournalPaper) i;
			System.out.println(jp);
		}
		if(i instanceof Video) {
			Video v = (Video) i;
			System.out.println(v);
		}
		if(i instanceof CD) {
			CD c = (CD) i;
			System.out.println(c);
		}
		
	}

}
