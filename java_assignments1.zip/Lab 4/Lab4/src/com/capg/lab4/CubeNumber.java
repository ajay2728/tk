package com.capg.lab4;

import java.util.Scanner;

public class CubeNumber {
	
	private int getCubeNumber(int n) {
		// TODO Auto-generated method stub
		int sum=0;
		while(n!=0) {
			int num=n%10;
			sum=sum+(num*num*num);
			n=n/10;
		}
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		CubeNumber cn=new CubeNumber();
		System.out.println("Enter the Value of 'n'");
		int n=in.nextInt();
		System.out.println("Cubic Sum of the digits of 'n':"+cn.getCubeNumber(n));
		in.close();
	}

}
