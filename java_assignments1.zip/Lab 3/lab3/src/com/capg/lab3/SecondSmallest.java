/**
 * 
 */
package com.capg.lab3;

import java.util.*;

/**
 * @author yabinand
 *
 */
public class SecondSmallest {

	private int getSecondSmallest(int[] b) {
		// TODO Auto-generated method stub
		ArrayList<Integer> s = new ArrayList<Integer>();
		for (int i = 0; i < b.length; i++) {
			s.add(b[i]);
		}
		Collections.sort(s);
		return s.get(1);

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		SecondSmallest ss = new SecondSmallest();
		System.out.println("Enter the Size of the Array");
		int n = in.nextInt();
		System.out.println("Enter the Elements of the Array");
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = in.nextInt();
		}
		System.out.println("Second Smallest in the Array is "
				+ ss.getSecondSmallest(a));
		in.close();
	}

}
