package com.capg.lab3;

import java.util.Scanner;

public class AlphaSort {
	
	private void getAlphaSort(String[] s) {
		String temp;
		for (int i = 0; i < s.length; i++) {
			for (int j = i+1; j < s.length; j++) {
				if((s[i].toLowerCase()).compareTo((s[j]).toLowerCase())>0) {
					temp=s[i];
					s[i]=s[j];
					s[j]=temp;
				}
			}
		}
		int n=s.length;
		if(n%2==0) {
			for(int i=0; i<(n/2); i++) {
				s[i]=s[i].toUpperCase();
			}
			for (int i =(n/2); i < n; i++) {
				s[i]= s[i].toLowerCase();
			}
		}
		else if(n%2!=0) {
			for(int i=0;i<(n/2)+1; i++) {
				s[i]= s[i].toUpperCase();
			}
			for(int i=(n/2)+1; i<n;i++) {
				s[i]= s[i].toLowerCase();
			}
		}
		System.out.println("The Sorted Strings are");
		for(String i:s){
			System.out.println(i);
		}
		

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		Scanner in = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		AlphaSort as = new AlphaSort(); 
		System.out.println("Enter the Size of the String Array");
		int n=in.nextInt();
		String[] a=new String[n];
		System.out.println("Enter the elements of the String Array");
		for(int i=0;i<n;i++) {
			a[i] = sc.nextLine();
		}
		as.getAlphaSort(a);
		in.close();
		sc.close();
	}

}
