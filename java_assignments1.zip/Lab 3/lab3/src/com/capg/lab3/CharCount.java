package com.capg.lab3;

import java.util.Scanner;

public class CharCount {
	
	private void getCharCount(char[] b) {
		// TODO Auto-generated method stub
		int k=0;
		for(int i=0; i<b.length; i++) {
			int count=0;
			for(int j=0;j<b.length;j++) {
				if(Character.toLowerCase(b[i])==Character.toLowerCase(b[j])) {
					count++;
				}
			}
			for (k = 0; k < i; k++) {
				if(Character.toLowerCase(b[k])==Character.toLowerCase(b[i])){
					break;
				}
			}
			if(k==i){
			System.out.println("The number of Occurences of Character "+Character.toLowerCase(b[i])+" is "+count);
			}	
		}
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		CharCount cc=new CharCount();
		System.out.println("Enter the Total Number of Characters");
		int n=in.nextInt();
		char s[]=new char[n];
		System.out.println("Enter the Characters for the Count");
		for(int i=0;i<n;i++) {
			String a=in.next();
			s[i]=a.charAt(0);
		}
		cc.getCharCount(s);
		in.close();
	}

}
