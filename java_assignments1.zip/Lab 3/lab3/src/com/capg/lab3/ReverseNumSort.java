package com.capg.lab3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ReverseNumSort {
	private int[] getSorted(int[] s) {
		// TODO Auto-generated method stub
		int n = s.length;
		int b[] = new int[n];
		String a[] = new String[n];
		ArrayList<String> rev = new ArrayList<String>();
		for (int i = 0; i < n; i++) {
			a[i] = Integer.toString(s[i]);
		}
		for (int i = 0; i < n; i++) {
			rev.add(new StringBuffer(a[i]).reverse().toString());
		}
		Collections.sort(rev);
		for (int i = 0; i < n; i++) {
			b[i] = Integer.parseInt(rev.get(i));
		}
		return b;// not returning exact array

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		ReverseNumSort rns = new ReverseNumSort();
		System.out.println("Enter the Total Number of Elements");
		int n = in.nextInt();
		int r[] = new int[n];
		int rs[] = new int[n];
		System.out.println("Enter the Elements of the Array");
		for (int i = 0; i < n; i++) {
			r[i] = in.nextInt();
		}
		rs = rns.getSorted(r);
		System.out.println("Reversed and Sorted array is ");
		for (int i : rs) {
			System.out.println(i);
		}
		in.close();
	}

}
