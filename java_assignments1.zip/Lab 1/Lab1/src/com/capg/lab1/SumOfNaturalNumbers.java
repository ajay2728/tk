package com.capg.lab1;

import java.util.Scanner;

/**
 * @author yabinand
 *
 */
public class SumOfNaturalNumbers {
	int sum = 0;

	/**
	 * @param n
	 * @return
	 */
	public int calculateSum(int n) {
		// TODO Auto-generated method stub
		sum = sum + n;
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SumOfNaturalNumbers sn = new SumOfNaturalNumbers();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Value of 'n'");
		int n = in.nextInt();
		while (n != 0) {
			if (n % 3 == 0 || n % 5 == 0) {
				sn.calculateSum(n);
			}
			n--;
		}
		System.out.println("Sum of the given 'n' natural numbers divisible by 3 or 5 is "
						+ sn.calculateSum(n));
		in.close();
	}
}
