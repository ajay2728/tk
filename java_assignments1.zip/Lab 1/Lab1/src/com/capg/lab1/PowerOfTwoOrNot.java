/**
 * 
 */
package com.capg.lab1;

import java.util.Scanner;

/**
 * @author yabinand
 *
 */
public class PowerOfTwoOrNot {
	/**
	 * @param args
	 */
	int count = 0;
	int num = 0;
	int temp = 2;

	public boolean checkNumber(int n) {
		// TODO Auto-generated method stub
		num = n;
		while (n != 0) {
			if ((n % 2) == 0) {
				count++;
			}
			n = n / 2;
		}
		while (count != 1) {
			temp = temp * 2;
			count--;
		}
		if (temp == num) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		PowerOfTwoOrNot sn = new PowerOfTwoOrNot();
		System.out.println("Enter the Number to Find Whether its Power of 2 or Not");
		int s = in.nextInt();
		System.out.println(sn.checkNumber(s));
		in.close();
	}
}
