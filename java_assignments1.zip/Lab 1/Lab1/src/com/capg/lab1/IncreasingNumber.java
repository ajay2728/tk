package com.capg.lab1;

import java.util.Scanner;

public class IncreasingNumber {
	int n = 0;
	int c = 0;
	int d = 0;
	int temp = 0;

	public boolean checkNumber(int number) {
		// TODO Auto-generated method stub
		while (number != 0) {
			n = number % 10;
			c = number / 10;
			if (n >= (c % 10)) {
				temp = 1;
			} else {
				temp = 0;
				break;
			}
			number = number / 10;
		}
		if (temp == 1) {
			return true;
		} else {
			return false;
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Number to Find Whether its an Increasing Number or Not");
		IncreasingNumber i = new IncreasingNumber();
		int N = in.nextInt();
		System.out.println(i.checkNumber(N));
		in.close();
	}

}
