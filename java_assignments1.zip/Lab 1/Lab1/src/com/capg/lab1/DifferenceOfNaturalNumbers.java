/**
 * 
 */
package com.capg.lab1;

import java.util.Scanner;

/**
 * @author yabinand
 *
 */
public class DifferenceOfNaturalNumbers {
	int diff = 0;
	int sum = 0;

	/**
	 * @param args
	 */
	public int calculateDifference(int s, int q) {
		// TODO Auto-generated method stub
		int diff = s - q;
		return diff;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SumOfNaturalNumbers sm = new SumOfNaturalNumbers();
		SumOfNaturalNumbers sm1 = new SumOfNaturalNumbers();
		DifferenceOfNaturalNumbers dn = new DifferenceOfNaturalNumbers();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Value of 'n'");
		int n = in.nextInt();
		int s = 0;
		int c = 0;
		while (n != 0) {
			s = sm.calculateSum(n * n);
			c = sm1.calculateSum(n);
			n--;
		}
		System.out
				.println("Difference of Square of first 'n' integers and Square of the sum is");
		System.out.println(dn.calculateDifference(c * c, s));
		in.close();

	}

}
