package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyControllerr {
    @RequestMapping("/")
	public String m1(ModelMap map) {
		map.addAttribute("msg" ,"to spring MVC");
		return "home";
		
	}
    
    @RequestMapping("/input")
    public ModelAndView inputdata() {
    	return new ModelAndView("inputpage");
    }
    
    @RequestMapping("/output")
    public ModelAndView resultdata(@RequestParam String name) {
    	String str = "Hello " + name;
    	return new ModelAndView("output" , "myname" ,str);
    }
}
