package com.cg;

import java.util.LinkedHashMap;
import java.util.Scanner;

public class SquareMap {
	
	public static LinkedHashMap<Integer, Integer> getSquare(int[] a) {
		LinkedHashMap<Integer, Integer> squarecount = new LinkedHashMap<Integer, Integer>();
		int k=0;
		for (int i = 0; i < a.length; i++) {
			int square = a[i]*a[i];
			for(k=0; k<i; k++) {
				if(a[k]==a[i]) {
					break;
				}
			}
			if(k==i) {
				squarecount.put(a[k], square);
			}
		}
		return squarecount;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Total Number of Integers");
		int n = in.nextInt();
		int a[] = new int[n];
		System.out.println("Enter the Integers");
		for (int i = 0; i < n; i++) {
			a[i] = in.nextInt();	
		}
		System.out.println(getSquare(a));
		in.close();
	}

}
