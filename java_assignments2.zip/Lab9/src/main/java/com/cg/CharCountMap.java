package com.cg;

import java.util.LinkedHashMap;
import java.util.Scanner;


public class CharCountMap {
	
	public static LinkedHashMap<Character, Integer> countCharacter(char[] c) {
		LinkedHashMap<Character, Integer> countchar = new LinkedHashMap<Character, Integer>();
		int k=0;
		for (int i = 0; i < c.length; i++) {
			int count=0;
			for (int j = 0; j < c.length; j++) {
				if(Character.toLowerCase(c[i])==Character.toLowerCase(c[j])) {
					count++;
				}
			}
			for(k=0; k<i; k++) {
				if(Character.toLowerCase(c[k])==Character.toLowerCase(c[i])){
					break;
				}
			}
			if(k==i) {
			countchar.put(Character.toUpperCase(c[k]), count);
			}
		}
		return countchar;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the total number of Characters");
		int n = in.nextInt();
		char c[] = new char[n];
		System.out.println("Enter the characters one by one");
		for (int i = 0; i < n; i++) {
			String c1 = in.next();
			c[i]=c1.charAt(0);
		}
		System.out.println(countCharacter(c));
		in.close();
	}

}
