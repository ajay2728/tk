package com.cg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class CollectionSort {
	
	public List<Integer> getValues(HashMap<Integer, Integer> map) {
		// TODO Auto-generated method stub
		Collection<Integer> collect = map.values();
		List<Integer> list = new ArrayList<Integer>();
		list.addAll(collect);
		Collections.sort(list);
		return list;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		CollectionSort cs = new CollectionSort();
		System.out.println("Enter the Total Number of values to be inserted");
		int n = in.nextInt();
		System.out.println("Enter "+n+" values with keys as first and  values second");
		while(n!=0) {	
			int key = in.nextInt();
			int value = in.nextInt();
			map.put(key, value);
			n--;
		}
		System.out.println("sorted List is"+cs.getValues(map));
		in.close();
		
	}

}
