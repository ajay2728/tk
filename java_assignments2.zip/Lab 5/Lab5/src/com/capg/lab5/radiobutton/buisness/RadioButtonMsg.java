package com.capg.lab5.radiobutton.buisness;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

public class RadioButtonMsg extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JRadioButton J1;
	JRadioButton J2;
	JRadioButton J3;
	JButton B1;
	ButtonGroup G1;
	JLabel L1;

	public RadioButtonMsg() {
		// TODO Auto-generated constructor stub
		this.setLayout(null);
		J1 = new JRadioButton();
		J2 = new JRadioButton();
		J3 = new JRadioButton();
		B1 = new JButton("OK");
		G1 = new ButtonGroup();
		L1 = new JLabel("TRAFFIC LIGHT");
		J1.setText("Red");
		J2.setText("Yellow");
		J3.setText("Green");
		J1.setBounds(125, 30, 60, 50);
		J2.setBounds(200, 30, 80, 50);
		J3.setBounds(290, 30, 60, 50);
		B1.setBounds(180, 90, 80, 30);
		L1.setBounds(20, 30, 150, 50);
		this.add(J1);
		this.add(J2);
		this.add(J3);
		this.add(B1);
		this.add(L1);
		G1.add(J1);
		G1.add(J2);
		G1.add(J3);
		B1.addActionListener(new ActionListener() {
			String msg;

			@Override
			public void actionPerformed(ActionEvent e) {
				if (J1.isSelected()) {
					msg = "STOP";
				} else if (J2.isSelected()) {
					msg = "READY";
				} else if (J3.isSelected()) {
					msg = "GO";
				} else {
					msg = "No Option Selected";
				}
				JOptionPane.showMessageDialog(RadioButtonMsg.this, msg);
			}
		});
	}
}
