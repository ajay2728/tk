package com.capg.lab5.radiobutton.client;

import com.capg.lab5.radiobutton.buisness.RadioButtonMsg;

public class RadioButton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RadioButtonMsg rbm = new RadioButtonMsg();
		rbm.setBounds(100, 100, 400, 200);
		rbm.setTitle("RadioButtons");
		rbm.setVisible(true);
	}

}
