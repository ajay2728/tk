package com.capg.lab5.exception;

public class FirstNameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "First Name cannot be Blank";
	}
	
	
}
