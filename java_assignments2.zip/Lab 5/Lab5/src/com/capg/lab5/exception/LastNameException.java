package com.capg.lab5.exception;

public class LastNameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Last Name cannot be Blank";
	}
	
	
	
}
