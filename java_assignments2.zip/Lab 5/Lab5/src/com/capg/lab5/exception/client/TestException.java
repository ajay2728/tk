package com.capg.lab5.exception.client;

import java.util.Scanner;

import com.capg.lab5.exception.FirstNameException;
import com.capg.lab5.exception.LastNameException;

public class TestException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Full Name of the Employee");
		String fullName = in.nextLine();
		try {
			int i = fullName.indexOf(" ");
			String s2 = fullName.substring(i + 1, fullName.length());
			if (fullName.equals("") || fullName.equals(null)) {
				try {
					throw new FirstNameException();
				} catch (FirstNameException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				} finally {
					in.close();
				}
			} else if (s2.equals("") || s2.equals(null)) {
				try {
					throw new LastNameException();
				} catch (LastNameException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				} finally {
					in.close();
				}
			} else {
				System.out.println("Name of the Employee:" + fullName);

			}
		} finally {
			in.close();
		}
	}
}
