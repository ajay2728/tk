package com.capg.lab5.exception;

public class ValidateAgeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Age should be above 15";
	}
	

}
