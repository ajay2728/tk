package com.capg.lab5.exception.client;

import java.util.Scanner;

import com.capg.lab5.exception.ValidateAgeException;

public class AgeException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Age");
		try {
			int n=in.nextInt();
			if(n<15) {
				throw new ValidateAgeException();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		finally {
			in.close();
		}
	}

}
