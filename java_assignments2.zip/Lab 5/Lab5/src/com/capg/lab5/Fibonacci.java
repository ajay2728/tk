/**
 * 
 */
package com.capg.lab5;

import java.util.Scanner;

/**
 * @author yabinand
 *
 */

public class Fibonacci {
	int f1 = 1;
	int f2 = 1;
	int fn = 0;
	private int getFibRecur(int n) {

		if(n>2) {
		fn = f1 + f2;
		f1 = f2;
		f2 = fn;
		getFibRecur(n-1);
		}
		return fn;
	} 
	
	 

	private int getFibNonRecur(int n) {
		// TODO Auto-generated method stub
		int f1 = 1;
		int f2 = 1;
		int fn = 0;
		for (int i = 3; i <= n; i++) {
			fn = f1 + f2;
			f1 = f2;
			f2 = fn;
		}
		return fn;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		Fibonacci f = new Fibonacci();
		System.out.println("Enter the number to print the nth value of the fibonacci Series");
		int n = in.nextInt();
		System.out.println("The nth value of the fibonacci sequence of " + n
				+ " using recursive function is " + f.getFibRecur(n));
		System.out.println("The nth value of the fibonacci sequence of " + n
				+ " using non recursive function is " + f.getFibNonRecur(n));
		in.close();
	}

}
