package com.capg.lab5;

import java.util.Scanner;

public class PrimeNumber {
	public void getPrimeNumber(int n) {
		// TODO Auto-generated method stub
		int i = 0;
		int num = 0;
		String prim = " ";
		for(i=1;i<=n;i++) {
			int count=0;
			for(num=i; num>=1; num--) {
				if(i%num==0) {
					count = count +1;
				}
			}
			if(count==2) {
				prim = prim + i + " ";
			}
		}
		System.out.println("Prime Numbers till "+n);
		System.out.println(prim);
				
	}	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		PrimeNumber pn = new PrimeNumber();
		System.out.println("Enter the Number upto which you want to display the prime numbers");
		int n = in.nextInt();
		pn.getPrimeNumber(n);
		in.close();
	}

}
