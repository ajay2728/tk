package com.cg.eis.exception.client;

import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class TestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the salary of the Employee");
		int salary = in.nextInt();
		if(salary<3000) {
				try {
					throw new EmployeeException();
				}
				catch (EmployeeException e) {
					// TODO: handle exception
					//e.printStackTrace();
					System.out.println(e.getMessage());
				}
				finally {
					in.close();
				}
			}
		else {
			System.out.println("The Entered Salary is "+salary);
		}
		in.close();
	}

}
