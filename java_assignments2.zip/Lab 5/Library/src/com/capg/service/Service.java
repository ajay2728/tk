package com.capg.service;

import com.capg.library.Book;
import com.capg.library.CD;
import com.capg.library.Item;
import com.capg.library.JournalPaper;
import com.capg.library.Video;

public class Service {
	public void processLibrary(Item i) {
		// TODO Auto-generated method stub
		if(i instanceof Book) {
			Book b = (Book) i;
			System.out.println(b);
		}
		else if(i instanceof JournalPaper) {
			JournalPaper jp = (JournalPaper) i;
			System.out.println(jp);
		}
		else if(i instanceof Video) {
			Video v = (Video) i;
			System.out.println(v);
		}
		else if(i instanceof CD) {
			CD c = (CD) i;
			System.out.println(c);
		}
	}
}
