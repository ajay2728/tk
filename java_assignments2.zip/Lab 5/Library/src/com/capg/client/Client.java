package com.capg.client;

import java.util.Scanner;

import com.capg.library.Book;
import com.capg.library.CD;
import com.capg.library.Item;
import com.capg.library.JournalPaper;
import com.capg.library.Video;
import com.capg.service.Service;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		Service serv=new Service();
		Item i;
		int uid;
		String title;
		int noOfCopies;
		String author;
		int yearPublished;
		String director;
		String genre;
		int yearReleased;
		String artist;
		int runtime;
		System.out.println("1.Book 2.Journal Paper 3.Video 4.java");
		System.out.println("Enter the Option");
		int option = in.nextInt();
		String choice = " ";
		do {
			switch (option) {
			case 1: {
				System.out.println("Enter the Unique Identification Number(uid) of the Book");
				uid = in.nextInt();
				System.out.println("Enter the Title of the Book");
				title = sc.nextLine();
				System.out.println("Enter the No. of Copies of the Book");
				noOfCopies = in.nextInt();
				System.out.println("Enter the Author of the Book");
				author = sc.nextLine();
				i = new Book(uid, title, noOfCopies, author);
				serv.processLibrary(i);
			}
				break;
			case 2: {
				System.out.println("Enter the Unique Identification Number(uid) of the Journal Paper");
				uid = in.nextInt();
				System.out.println("Enter the Title of the Journal Paper");
				title = sc.nextLine();
				System.out.println("Enter the No. of Copies of the Journal Paper");
				noOfCopies = in.nextInt();
				System.out.println("Enter the Author of the JournalPaper");
				author = sc.nextLine();
				System.out.println("Enter the Published Year of the JournalPaper");
				yearPublished = in.nextInt();
				i = new JournalPaper(uid, title, noOfCopies, author, yearPublished);
				serv.processLibrary(i);
			}
				break;
			case 3: {
				System.out.println("Enter the Unique Identification Number(uid) of the Video");
				uid = in.nextInt();
				System.out.println("Enter the Title of the Video");
				title = sc.nextLine();
				System.out.println("Enter the No. of Copies of the Video");
				noOfCopies = in.nextInt();
				System.out.println("Enter the Director of the Video");
				director = sc.nextLine();
				System.out.println("Enter the Genre of the Video");
				genre = in.next();
				System.out.println("Enter the Year the Video got Released");
				yearReleased = in.nextInt();
				System.out.println("Enter the Runtime of the Video");
				runtime = in.nextInt();
				i = new Video(uid, title, noOfCopies, runtime, director, genre, yearReleased);
				serv.processLibrary(i);
			}
				break;
			case 4: {
				System.out.println("Enter the Unique Identification Number(uid) of the CD");
				uid = in.nextInt();
				System.out.println("Enter the Title of the CD");
				title = sc.nextLine();
				System.out.println("Enter the No. of Copies of the CD");
				noOfCopies = in.nextInt();
				System.out.println("Enter the Artist of the CD");
				artist = sc.nextLine();
				System.out.println("Enter the Genre of the CD");
				genre = in.next();
				System.out.println("Enter the Runtime of the CD");
				runtime = in.nextInt();
				i = new CD(uid, title, noOfCopies, runtime, artist, genre);
				serv.processLibrary(i);
			}
				break;
			}
			System.out.println("Enter Y to continue");
			choice = in.next();
		} while (choice.equalsIgnoreCase("Y"));
		in.close();
		sc.close();
	}

}
