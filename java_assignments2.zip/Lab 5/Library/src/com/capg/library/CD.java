package com.capg.library;

public class CD extends MediaItem {
	private String artist;
	private String genre;

	public CD() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CD(int uid, String title, int noOfCopies, int runtime) {
		super(uid, title, noOfCopies, runtime);
		// TODO Auto-generated constructor stub
	}

	public CD(int uid, String title, int noOfCopies) {
		super(uid, title, noOfCopies);
		// TODO Auto-generated constructor stub
	}

	public CD(int uid, String title, int noOfCopies, int runtime, String artist, String genre) {
		this(uid, title, noOfCopies, runtime);
		this.artist = artist;
		this.genre = genre;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

}
