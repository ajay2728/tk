/**
 * 
 */
package com.capg.library;

/**
 * @author Yuvanesh
 *
 */
public abstract class WrittenItem extends Item {
	private String author;

	public WrittenItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WrittenItem(int uid, String title, int noOfCopies) {
		super(uid, title, noOfCopies);
		// TODO Auto-generated constructor stub
	}

	public WrittenItem(int uid, String title, int noOfCopies, String author) {
		this(uid,title,noOfCopies);
		this.author = author;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "WrittenItem ["+super.toString()+" author=" + author + "]";
	}

	
	
	
}
