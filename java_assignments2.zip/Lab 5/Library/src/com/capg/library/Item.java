/**
 * 
 */
package com.capg.library;

/**
 * @author Yuvanesh
 *
 */
public abstract class Item {
	private int uid;
	private String title;
	private int noOfCopies;

	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Item(int uid, String title, int noOfCopies) {
		super();
		this.uid = uid;
		this.title = title;
		this.noOfCopies = noOfCopies;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getNoOfCopies() {
		return noOfCopies;
	}

	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}

	@Override
	public String toString() {
		return " uid=" + uid + ", title=" + title + ", noOfCopies=" + noOfCopies;
	}

}
