package com.capg.lab8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UNameValidator {
	static Pattern namptn = Pattern.compile("^[a-zA-z0-9_@]{12,16}$");
	public static boolean validateName(String name) {
		Matcher match = namptn.matcher(name);
		if(match.matches()) {
			if(name.endsWith("_job")) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Username");
		String name = in.next();
		if(validateName(name)) {
			System.out.println("Valid User Name");
		}
		else {
			System.out.println("Invalid User Name");
			System.out.println("User Name must not contain any symbols other than @,_");
			System.out.println("User Name must end with _job");
			System.out.println("Mininum User Name length is 12 and Maximum is 16");
		}
		in.close();
	}

}
