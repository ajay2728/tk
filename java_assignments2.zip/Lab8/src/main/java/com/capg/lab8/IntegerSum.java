package com.capg.lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class IntegerSum {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a Line of Integer with space between each Integer");
		String s = in.nextLine();
		StringTokenizer st = new StringTokenizer(s, " ");
		int n = 0;
		int sum = 0;
		System.out.println("Each Integer Present in the String are:");
		while(st.hasMoreTokens()) {
				n = Integer.parseInt(st.nextToken());
				System.out.println(n);
				sum = sum + n;
		}
		System.out.println("The sum of the Integers is " +sum);
		in.close();
		
	}

}
