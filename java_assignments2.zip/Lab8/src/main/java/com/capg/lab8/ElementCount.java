package com.capg.lab8;

import java.io.FileInputStream;
import java.io.IOException;

public class ElementCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(FileInputStream fin = new FileInputStream("src/hi.txt");) {		
			int i = 0;
			int charCount=0;
			int lineNumber = 0;
			int wordCount = 0;
			while (i != -1) {
				i = fin.read();
				charCount = charCount+1;
				char c = (char)i;
				if(c =='\n') {
					lineNumber = lineNumber + 1;
				}
				if(c == ' ') {
					wordCount = wordCount + 1;
				}
			}
			System.out.println("The Number of Characters in the file: "+ charCount);
			System.out.println("The Number of Lines in the file:" + lineNumber);
			System.out.println("The Number of Words in the file:" + wordCount);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
