package com.capg.lab8;

import java.io.File;

public class FileInformation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1 = new File("src/hi.txt");
		System.out.print(f1.getName());
		System.out.println(f1.exists()?" File Exists":" File does not exist");
		System.out.println(f1.getName()+" is Readable:"+f1.canRead());
		System.out.println(f1.getName()+" is Writable:"+f1.canWrite());
		System.out.println("The Size of the file "+f1.getName()+" in bytes is " +f1.length());
		String fileName = f1.getName();
		String exn = fileName.substring(fileName.indexOf(".")+1,fileName.length());
		System.out.println(f1.getName()+" is a "+ exn + "  file");
	}

}
