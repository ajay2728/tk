package com.capg.lab8;

import java.util.Scanner;

public class PositiveString {
	public boolean getPositiveString(String s) {
		int temp = 0;
		int n=0;
		int c=0;
		for(int i = 0; i < s.length(); i++) {
			s = s.toLowerCase();
			n = (int)(s.charAt(i));
			if(i<=(s.length())-2) {
				c = (int)s.charAt(i+1);
			}
			if(n <= c) {
				temp=1;
			}
			else {
				temp=0;
				break;
			}
		}
		if(temp==1) {
			return true;
		}
		else {
			return false;
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		PositiveString ps = new PositiveString();
		System.out.println("Enter the String");
		String str = in.next();
		if(ps.getPositiveString(str)) {
			System.out.println("Positive String");
		}
		else {
			System.out.println("Negative String");
		}
		in.close();
	}

}
