package com.capg.lab8;

import java.io.FileInputStream;
import java.io.IOException;

public class FileReader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(FileInputStream fin = new FileInputStream("src/main/java/com/capg/lab8/FileReader.java")) {
			int i=0;
			int lineNumber=1;
			while(i!=-1) {
				i = fin.read();
				if((char)i=='\n') {
					System.out.print(lineNumber+" ");
					lineNumber++;
				}
				System.out.print((char)i);
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

}
