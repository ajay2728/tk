package com.capg.lab8;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateInput {
	public void getDate(String date) {
		// TODO Auto-generated method stub
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate d = LocalDate.parse(date,formatter);
			LocalDate d1 = LocalDate.now();
			Period diff = Period.between(d, d1);
			System.out.println("Duration in days:"+diff.getDays());
			System.out.println("Duration in months:"+diff.getMonths());
			System.out.println("Duration in years:"+diff.getYears());
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the date in dd/MM/yyyy format");
		String date = in.next();
		DateInput d = new DateInput();
		d.getDate(date);
		in.close();
	}

}
