package com.cg.lab11.concurrentpatterns;

import java.util.Scanner;

public class TimerRefresh implements Runnable {

	@Override
	public void run() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Timer in Seconds");
		int choice = 0;
		do {
			System.out.println("1.Start 2. Stop");
			choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				for (int i = 1; i <= 10; i++) {
					System.out.println(i);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}break;
			}
		} while (choice != 2);
		scanner.close();
	}

}
