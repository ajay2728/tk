package com.cg.lab11.concurrentpatterns;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread{
	FileInputStream fin;
	public CopyDataThread(FileInputStream fin) {
		super();
		this.fin = fin;
	}
	@Override
	public void run() {
		int i=0;
		try(FileOutputStream fout = new FileOutputStream("src/target.txt");) {
			int count =0;
			while(i!=-1) {
				i = fin.read();
				fout.write(i);
				count = count+1;
				if(count==11) {
					Thread.sleep(5000);
					System.out.print(" 10 characters are copied");
					System.out.println("\n");
					count =1;
				}
				System.out.print((char)i);
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		} 
	}
}
