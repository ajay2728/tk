package com.cg.lab11concurrentpatterns.client;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cg.lab11.concurrentpatterns.TimerRefresh;

public class TimerRefreshImpl {

	public static void main(String[] args) {
		TimerRefresh tr1 = new TimerRefresh();
		ExecutorService es = Executors.newCachedThreadPool();
		es.execute(tr1);
	}

}
