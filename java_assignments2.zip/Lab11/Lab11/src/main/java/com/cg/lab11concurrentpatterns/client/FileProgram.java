/**
 * 
 */
package com.cg.lab11concurrentpatterns.client;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cg.lab11.concurrentpatterns.CopyDataThread;

;

/**
 * @author yabinand
 *
 */
public class FileProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			FileInputStream fin = new FileInputStream("src/source.txt");
			CopyDataThread cdt = new CopyDataThread(fin);
			ExecutorService es = Executors.newSingleThreadExecutor();
			es.execute(cdt);
		} catch (IOException e) {

			e.printStackTrace();
		} 
	}

}
