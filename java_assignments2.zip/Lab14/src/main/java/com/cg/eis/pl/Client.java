/**
 * 
 */
package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.IEmployeeService;

/**
 * @author yabinand
 *
 */
public class Client {

	/**
	 * @param args Gets the employee details and prints the it back with appropriate
	 *             insurance scheme
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Scanner scanner2 = new Scanner(System.in);
		System.out.println("Enter Employee ID:");
		int id = scanner.nextInt();
		System.out.println("Enter the employee name:");
		String name = scanner2.nextLine().trim();
		System.out.println("Enter the employee salary:");
		double salary = scanner.nextDouble();
		System.out.println("Enter the employee designation:");
		String designation = scanner2.nextLine().trim();
		Employee employee = new Employee(id, name, salary, designation);
		IEmployeeService service = new EmployeeService();
		service.getInsuranceScheme(employee);
		System.out.println("Employee details with corresponding Insurance Scheme");
		System.out.println("Employee Id:" + employee.getId() + "\n" + "Employee Name:" + employee.getName() + "\n"
				+ "Employee Salary:" + employee.getSalary() + "\n" + "Employee Designation" + employee.getDesignation()
				+ "\n" + "Employee Insurance Scheme:" + employee.getInsuranceScheme());
		scanner.close();
		scanner2.close();

	}

}
