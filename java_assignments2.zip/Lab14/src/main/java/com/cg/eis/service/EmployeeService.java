package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeService implements IEmployeeService {

	@Override
	public void getInsuranceScheme(Employee employee) {
		if (employee.getDesignation().equalsIgnoreCase("system associate") && employee.getSalary() > 5000
				&& employee.getSalary() < 20000) {
			employee.setInsuranceScheme("Scheme C");
		} else if (employee.getDesignation().equalsIgnoreCase("programmer") && employee.getSalary() >= 20000
				&& employee.getSalary() < 40000) {
			employee.setInsuranceScheme("Scheme B");
		} else if (employee.getDesignation().equalsIgnoreCase("manager") && employee.getSalary() >= 40000) {
			employee.setInsuranceScheme("Scheme A");
		} else if (employee.getDesignation().equalsIgnoreCase("clerk") && employee.getSalary() < 5000) {
			employee.setInsuranceScheme("No Scheme");
		} else {
			System.out.println(
					"Either there is no such  designation or such salary offered in the Employee Insurance System");
		}
	}

}
