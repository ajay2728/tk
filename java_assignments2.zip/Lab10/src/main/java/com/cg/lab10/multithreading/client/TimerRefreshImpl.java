package com.cg.lab10.multithreading.client;

import com.cg.lab10.multithreading.TimerRefresh;

public class TimerRefreshImpl {

	public static void main(String[] args) {
		TimerRefresh tr1 = new TimerRefresh();
		Thread thread = new Thread(tr1);
		thread.start();
	}

}
