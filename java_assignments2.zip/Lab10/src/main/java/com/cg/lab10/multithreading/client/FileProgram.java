package com.cg.lab10.multithreading.client;

import java.io.FileInputStream;
import java.io.IOException;

import com.cg.lab10.multithreading.CopyDataThread;

public class FileProgram {

	public static void main(String[] args) {
		
		try {
			FileInputStream fin = new FileInputStream("src/source.txt");
			CopyDataThread cdt = new CopyDataThread(fin);
			cdt.start();
		} catch (IOException e) {

			e.printStackTrace();
		} 
		
	}

}
