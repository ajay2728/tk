package com.cg.lab13.userdetails;

import java.util.Scanner;

public class UserDetailsImpl {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter User Name");
		String userName = scanner.next().trim();
		System.out.println("Enter the Password");
		String password = scanner.next();
		UserDetails userdetails = (a,b) -> {
			boolean result =false;
			if(a.equals("yuvanesh")) {
				if(b.equals("yuvanesh@123")) {
					result = true; 
					return result;
				}
				else {
					result =false;
					return result;
				}
			}
			else {
				result = false;
				return result;
			}
		};
		System.out.println("Valid User:"+userdetails.getUserDetails(userName, password));
		scanner.close();
		
	}
}
