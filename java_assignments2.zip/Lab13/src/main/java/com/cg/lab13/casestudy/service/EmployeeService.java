package com.cg.lab13.casestudy.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.lab13.casestudy.bean.Employee;

public class EmployeeService implements IEmployeeService {
	public Optional<Double> getTotalSalary(Map<Integer, Employee> employeeMap) {
		Collection<Employee> collect =employeeMap.values();
		List<Employee> empList = new ArrayList<Employee>();
		empList.addAll(collect);
		List<Double> salList =  new ArrayList<Double>();
		for(Employee emp : empList) {
			 salList.add(emp.getSalary());
		}
		System.out.println(empList);
		System.out.println(salList);
		Optional<Double> totalSalary = salList.stream().reduce((a,b)->(a+b));
		return totalSalary;
 	}
}
