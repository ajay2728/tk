package com.cg.lab13.casestudy.repo;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.cg.lab13.casestudy.bean.Department;
import com.cg.lab13.casestudy.bean.Employee;

public class EmployeeRepository {
	static Map<Integer, Employee> employees =  new HashMap<Integer, Employee>();
	
	
	static {

		Department department = new Department(10,"Financial Services",110);
		Department department1 = new Department(20,"HR",120);
		Department department2 = new Department(30,"Sales",130);
		Employee employee = new Employee(101, "Sridhar", "Subramaninan", "sridhar@gmail.com", "8246142456", LocalDate.now(),
				"Analyst", 20000.00, 1001, department);
		Employee employee1 = new Employee(102, "Yuvanesh", "Abinandha", "yuvanesh@gmail.com", "9003362090", LocalDate.now(),
				"Analyst", 25000.00, 1002, department1);
		Employee employee2 = new Employee(103, "Dharneesh", "Kumar", "dharneesh@gmail.com", "9874563210", LocalDate.now(),
				"Analyst", 30000.00, 1003, department2 );
		
		employees.put(employee.getEmployeeId(), employee);
		employees.put(employee1.getEmployeeId(), employee1);
		employees.put(employee2.getEmployeeId(), employee2);
	}
	
	public static Map<Integer, Employee> getSalaries() {
		return employees;
	}
}
