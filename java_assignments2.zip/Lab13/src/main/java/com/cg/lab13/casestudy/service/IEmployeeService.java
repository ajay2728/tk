package com.cg.lab13.casestudy.service;

import java.util.Map;
import java.util.Optional;

import com.cg.lab13.casestudy.bean.Employee;

public interface IEmployeeService {
	public Optional<Double> getTotalSalary(Map<Integer, Employee> employeeMap);
}
