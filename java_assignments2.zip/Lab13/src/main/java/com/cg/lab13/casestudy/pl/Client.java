package com.cg.lab13.casestudy.pl;

import java.util.Optional;

import com.cg.lab13.casestudy.repo.EmployeeRepository;
import com.cg.lab13.casestudy.service.EmployeeService;
import com.cg.lab13.casestudy.service.IEmployeeService;

public class Client {

	public static void main(String[] args) {
		IEmployeeService service =  new EmployeeService();
		Optional<Double> totalSalary = service.getTotalSalary(EmployeeRepository.getSalaries());
		if(totalSalary.isPresent()) {
			System.out.println("Total Salary of the Employees"+totalSalary);
		}
		else {
			System.out.println("Nothing is returned");
		}
	}

}
