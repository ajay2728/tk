package com.cg.lab13.space;

import java.util.Scanner;

public class SpaceImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = scanner.next();
		Space space = (a) -> a.replaceAll(".(?!$)","$0 ");
		System.out.println("The Formatted String:"+space.putSpace(s));
		scanner.close();
	}

}
