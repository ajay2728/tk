package com.cg.lab13.lamdapower;

public interface Power {
	double getPower(double x,double y);
}
