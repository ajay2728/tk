package com.cg.lab13.lamdapower;

import java.util.Scanner;

public class LamdaPowerClient {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the value of 'x'");
		int x = scanner.nextInt();
		System.out.println("Enter the value of 'y'");
		int y = scanner.nextInt();
		Power pow = (a,b)-> Math.pow(a,b);
		System.out.println("The X power Y: "+pow.getPower(x, y));
		scanner.close();
	}

}
