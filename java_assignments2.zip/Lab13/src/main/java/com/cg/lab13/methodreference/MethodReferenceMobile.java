package com.cg.lab13.methodreference;

import java.util.Scanner;
import java.util.function.Supplier;
interface Say {
	String msg();
	double msg1();
}
public class MethodReferenceMobile {
	private String name;
	private double price;
	
	public String getName() {
		return name;
	}
	public  void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Mobile Name");
		String mobileName = scanner.next().trim();
		System.out.println("Enter the Mobile Price");
		double price = scanner.nextDouble();
		Supplier<MethodReferenceMobile> mobile=MethodReferenceMobile::new; 
		MethodReferenceMobile mf=mobile.get();
		mf.setName(mobileName);
		mf.setPrice(price);
		System.out.println("Mobile Name:"+mf.name);
		System.out.println("Mobile Price:"+mf.price);
		scanner.close();
	}

}
