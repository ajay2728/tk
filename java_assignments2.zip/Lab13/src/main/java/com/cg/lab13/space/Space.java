package com.cg.lab13.space;

public interface Space {
	String putSpace(String s);
}
