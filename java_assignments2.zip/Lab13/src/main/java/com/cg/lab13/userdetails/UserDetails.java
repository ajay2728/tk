package com.cg.lab13.userdetails;

public interface UserDetails {
	boolean getUserDetails(String username,String password);
}
