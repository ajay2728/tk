package com.cg.lab13.factorial;

import java.util.Scanner;
import java.util.function.Supplier;

public class Factorial {
	private static int getFactorial() {
		int fact =1;
		System.out.println("Enter the Number for Factorial");
		Scanner scanner = new Scanner(System.in);
		int n =  scanner.nextInt();
		while(n!=0) {
			fact = fact*n;
			n = n-1;		
		}
		scanner.close();
		return fact;
	}
	public static void main(String[] args) {
		System.out.println();
		Supplier<Integer> supp = Factorial::getFactorial;
		System.out.println("The Factorial Value:"+supp.get());
	}

}
