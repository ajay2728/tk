package com.cg.dao;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.beans.Customer;

@Repository
public class CustomerRepositoryImpl implements CustomerRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	@Override
	public void save(Customer customer) {
		entityManager.persist(customer);
	}

	@Transactional
	@Override
	public void update(Customer customer) {
		entityManager.merge(customer);
	}

	@Transactional
	@Override
	public boolean delete(int custId) {
		Customer customer = entityManager.find(Customer.class, custId);
		entityManager.remove(customer);
		Customer findcustomer = entityManager.find(Customer.class, custId);
		if (findcustomer == null)
			return true;
		else
			return false;
	}


	@Override
	public Customer getById(int custId) {
		Customer customer = entityManager.find(Customer.class, custId);
		return customer;
	}

	@Override
	public List<Customer> getCustomers() {
		TypedQuery<Customer> query = entityManager.createQuery("from Customer", Customer.class);
		List<Customer> customerList = query.getResultList();
		return customerList;
	}

	
	@Override
	public Customer validate(String username, String password) {
		TypedQuery<Customer> query = entityManager
				.createQuery("select c from Customer c where c.username=?1 and c.password=?2", Customer.class);
		query.setParameter(1, username);
		query.setParameter(2, password);
		Customer customer = query.getSingleResult();
		return customer;
	}

}
