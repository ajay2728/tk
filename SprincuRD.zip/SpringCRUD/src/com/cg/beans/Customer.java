package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "customerspring")
@Component
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "myseq")

	@SequenceGenerator(name = "myseq", sequenceName = "customerspringseq", initialValue = 3000, allocationSize = 1)
	@Column(length = 5)
	private int custId;
	@NotBlank(message = "User Name cannot be given blank")
	@Column(length = 30)
	private String username;
	@NotBlank(message = "Enter the password")
	@Pattern(regexp = "^[a-zA-Z0-9]{6}$", message = " password must be alphanumeric")
	@Column(length = 6)
	private String password;
	@NotNull(message = "must enter age")
	@Min(value = 18, message = "only adults are allowed")
	@Column(length = 3)
	private Integer age;
	
	@Email(message = "invalid email")
	@NotEmpty(message = "must enter mail")
	@Column(length = 30)
	private String email;
//@Pattern(regexp = "[0-9{10}]" , message = "phone number invalid")
	@NotNull(message = "provide phone number")
	@Column(length = 10)
	private Long phone;
	@Column(length = 150)
	private String address;
	@Column(length = 6)
	private String gender;
	@Column(length = 15)
	private String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getPhone() {
		return phone;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", username=" + username + ", password=" + password + ", age=" + age
				+ ", email=" + email + ", phone=" + phone + ", address=" + address + ", gender=" + gender + "]";
	}

}
