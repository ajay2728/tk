package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Customer;
import com.cg.beans.Gender;
import com.cg.dao.CustomerRepository;

@Controller
public class CustomerController {
	@Autowired
	Customer customer;
	@Autowired
	CustomerRepository customerRepository;

	@RequestMapping("/")
	public ModelAndView first() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("Login");
		return modelAndView;
	}

	@RequestMapping("/registerlink")
	public String registerLink(ModelMap map) {
		map.addAttribute(customer);
		return "register";
	}

	@RequestMapping("/register")
	public ModelAndView register(@Valid Customer customer, BindingResult errors) {
		ModelAndView modelAndView = new ModelAndView();
		if (errors.hasErrors()) {
			modelAndView.setViewName("register");
			modelAndView.addObject("status", "Not registered try it again");

		} else {
			customerRepository.save(customer);
			modelAndView.setViewName("Login");
			modelAndView.addObject("status", "Registered succesfully");
		}
		return modelAndView;
	}

	@ModelAttribute("genderList")
	public List<Gender> populate() {
		ArrayList<Gender> list = new ArrayList<Gender>();
		Gender g1 = new Gender();
		g1.setType("male");
		Gender g2 = new Gender();
		g2.setType("Female");
		list.add(g1);
		list.add(g2);
		return list;
	}

	@RequestMapping(value = "/loginvalidation", method = RequestMethod.POST)
	public ModelAndView validate(@RequestParam String username, @RequestParam String password,
			HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession session = request.getSession();
		customer = customerRepository.validate(username, password);
		if (customer != null) {
			if (customer.getRole().equalsIgnoreCase("admin")) {
				modelAndView.setViewName("adminhome");
			} else {
				session.setAttribute("customer", customer);
				modelAndView.setViewName("customerhomepage");
			}
		}

		else {
			modelAndView.addObject("status", "Invalid username/password");
			modelAndView.setViewName("Login");
		}
		return modelAndView;
	}

	@RequestMapping("/viewprofile")
	public String viewProfile() {
		return "customerhomepage";
	}

	@RequestMapping("/updateprofile")
	public String updateprofile(Model map, HttpServletRequest request) {
		customer = (Customer) request.getSession().getAttribute("customer");
		map.addAttribute(customer);
		return "update";
	}

	@RequestMapping("/updatedata")
	public ModelAndView updatedata(@Valid Customer customer, BindingResult errors) {
		ModelAndView modelAndView = new ModelAndView();
		if (errors.hasErrors()) {
			modelAndView.setViewName("update");
			modelAndView.addObject("status", "Not updated try it again");

		} else {
			customerRepository.update(customer);
			modelAndView.setViewName("Login");
			modelAndView.addObject("status", "updated succesfully");
		}
		return modelAndView;
	}

	@RequestMapping("/viewall")
	public ModelAndView viewall() {
		ModelAndView modelAndView = new ModelAndView();
		List<Customer> customeList = customerRepository.getCustomers();
		modelAndView.addObject("customerList", customeList);
		modelAndView.setViewName("adminhome");
		return modelAndView;
	}

	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam Integer custId) {
		ModelAndView modelAndView = new ModelAndView();
		boolean status = customerRepository.delete(custId);
		if (status) {
			modelAndView.addObject("status", "deleted successfully");

		} else
			modelAndView.addObject("status", "not deleted");
		modelAndView.setViewName("adminhome");
		return modelAndView;
	}

	/*
	 * @RequestMapping("/viewbyId") public ModelAndView viewById(@RequestParam
	 * Integer custId) { ModelAndView modelAndView = new ModelAndView(); Customer
	 * customer = customerRepository.getById(custId);
	 * modelAndView.addObject("customer", customer);
	 * modelAndView.setViewName("adminhome"); return modelAndView; }
	 */
	@RequestMapping("/viewbyid")
	public String viewById() {
		return "viewbyid";
	}

	@RequestMapping("/viewdata")
	public ModelAndView viewdata(@RequestParam Integer custId) {
		ModelAndView modelAndView = new ModelAndView();
		customer = customerRepository.getById(custId);
		modelAndView.addObject("customer", customer);
		modelAndView.setViewName("viewbyid");
		return modelAndView;
	}
}